export const presentationLocale = { lang: 'en', dir: 'ltr' };

export const ui = {
  noSlides: 'No slides yet.',
  slides: 'Slides',
  backToSlides: 'Back to slides',
  fullscreen: 'Fullscreen',
  exit: 'Exit',
  exitPresentation: 'Exit presentation',
  speakerControls: 'Speaker controls',
  previousSlide: 'Previous slide',
  nextSlide: 'Next slide',
  timer: 'Timer',
  reset: 'Reset',
  audienceTab: 'Audience tab',
  openTab: 'Open tab',
  audienceHelp: 'Opens a clean display for the projector or shared browser window. This speaker interface controls it locally.',
  speakerNotes: 'Speaker notes',
  noNotes: 'No notes for this slide.',
  next: 'Next',
  printHelp: 'Use your browser\'s Print (Cmd/Ctrl+P) and choose "Save as PDF".',
  slidePosition: (number, total) => `Slide ${number} / ${total}`,
};
