import Slide01Title from './content/Slide01Title';
import Slide02Problem from './content/Slide02Problem';
import Slide02bThoughtProcess from './content/Slide02bThoughtProcess';
import Slide03Platform from './content/Slide03Platform';
import Slide04bPersonalAgentOutreach from './content/Slide04bPersonalAgentOutreach';
import Slide04DiscoveryStyles from './content/Slide04DiscoveryStyles';
import Slide05ContinuousLearning from './content/Slide05ContinuousLearning';
import Slide06SimulationDecision from './content/Slide06SimulationDecision';
import Slide07GamificationReports from './content/Slide07GamificationReports';
import Slide08PartnershipsRouter from './content/Slide08PartnershipsRouter';
import Slide09PredictiveROI from './content/Slide09PredictiveROI';
import Slide10BudgetRoadmap from './content/Slide10BudgetRoadmap';

export const slides = [
  {
    id: 'title-platform',
    title: 'AI Workforce Intelligence Platform',
    subtitle: 'Executive Transformation & Venture Briefing',
    Component: Slide01Title,
  },
  {
    id: 'workforce-sales-problem',
    title: 'The Workforce & Sales Performance Problem',
    subtitle: 'Activity Surge vs. Flat Revenue',
    Component: Slide02Problem,
  },
  {
    id: 'our-thought-process',
    title: 'Understand How to Solve the Problem Through AI',
    subtitle: 'Brainstorm → Consensus & Uni DBs → Base44',
    Component: Slide02bThoughtProcess,
  },
  {
    id: 'introducing-platform',
    title: 'The AI Workforce Intelligence Platform',
    subtitle: '3 Core Intelligence Engines',
    Component: Slide03Platform,
  },
  {
    id: 'personal-agent-outreach',
    title: 'Personal Employee AI Agent & Public Data Outreach',
    subtitle: 'LinkedIn + ZoomInfo + Public Intel → 1:1 Emails',
    Component: Slide04bPersonalAgentOutreach,
  },
  {
    id: 'discovery-personality-styles',
    title: 'Buyer Intel, Top-Rep DNA & 4 Coaching Styles',
    subtitle: 'Call + Web Needs & Reframed Strengths',
    Component: Slide04DiscoveryStyles,
  },
  {
    id: 'continuous-learning-coaching',
    title: 'Closed-Deal Reviews & Win vs. Loss Benchmarking',
    subtitle: 'Outcomes Over Email Counts',
    Component: Slide05ContinuousLearning,
  },
  {
    id: 'persona-simulation-decision-engine',
    title: 'Persona Sales Simulator & Bias Shield',
    subtitle: 'Voice/Video Loss Replay & Vocal Coaching',
    Component: Slide06SimulationDecision,
  },
  {
    id: 'gamification-weekly-reports',
    title: 'Weekly 2-Way AI Check-Ins & Smart Gamification',
    subtitle: 'Mutual AI Interviews & Skill Rewards',
    Component: Slide07GamificationReports,
  },
  {
    id: 'predictive-analytics-roi',
    title: 'Predictive Impact, Capacity & ROI',
    subtitle: '+$1.44M ARR & +9.0 dCUs',
    Component: Slide09PredictiveROI,
  },
  {
    id: 'partnerships-model-router',
    title: 'AI Partnerships & Model Router',
    subtitle: 'Multi-LLM Orchestration (40% - 70% Savings)',
    Component: Slide08PartnershipsRouter,
  },
  {
    id: 'budget-roadmap-vision',
    title: '$9,850 Pilot, 90-Day Roadmap & Vision',
    subtitle: 'Turnkey Rollout Under $10K Cap',
    Component: Slide10BudgetRoadmap,
  },
];