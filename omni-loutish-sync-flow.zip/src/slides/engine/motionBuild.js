const STEP_MS = 400;

const orderOf = (element) => {
  const order = Number(element.dataset.motionOrder);
  return Number.isInteger(order) && order >= 1 && order <= 10 ? order : 1;
};

export function applyMotionBuild(surface, build) {
  const elements = Array.from(surface.querySelectorAll('[data-motion]'));
  const clicks = build
    ? [...new Set(elements.filter((element) => element.dataset.motionStart === 'click').map(orderOf))].sort((a, b) => a - b)
    : [];
  for (const element of elements) {
    const order = orderOf(element);
    const group = clicks.filter((click) => click <= order).length;
    if (group) element.style.animationDelay = `${(order - clicks[group - 1]) * STEP_MS}ms`;
    else element.style.removeProperty('animation-delay');
    element.toggleAttribute('data-motion-waiting', Boolean(build) && group > build.step);
    element.toggleAttribute('data-motion-instant', Boolean(build) && group < build.settled);
  }
  return clicks.length;
}
