import { useEffect, useRef } from 'react';
import { slides } from '@/slides/slides';

const CHANNEL_NAME = 'base44:presentation';
const STORAGE_KEY = 'base44:presentation:state';
const MESSAGE_TYPE = 'presentation:slide';
const MESSAGE_VERSION = 1;

function parseSlideMessage(value, slides) {
  if (typeof value !== 'object' || value === null) return null;
  const { type, version, id, step } = value;
  if (type !== MESSAGE_TYPE) return null;
  if (version !== MESSAGE_VERSION) return null;
  if (typeof id !== 'string') return null;
  if (!slides.some((slide) => slide.id === id)) return null;
  return { id, step: Number.isInteger(step) && step > 0 ? step : 0 };
}

function createMessage(id, step) {
  return { type: MESSAGE_TYPE, version: MESSAGE_VERSION, id, step, updatedAt: Date.now() };
}

export function publishPresentationSlide(id, step = 0) {
  const message = createMessage(id, step);

  if ('BroadcastChannel' in window) {
    const channel = new BroadcastChannel(CHANNEL_NAME);
    channel.postMessage(message);
    channel.close();
  }

  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(message));
  } catch {
    // Private browsing or embedded contexts may block localStorage.
  }
}

export function usePresentationSync(onSlide, enabled = true) {
  const hydrated = useRef(false);
  const handler = useRef(onSlide);
  handler.current = onSlide;
  useEffect(() => {
    if (!enabled) {
      hydrated.current = false;
      return;
    }
    const handleMessage = (event) => {
      const slide = parseSlideMessage(event.data, slides);
      if (slide) handler.current(slide.id, slide.step);
    };

    const handleStorage = (event, joining = false) => {
      if (event.key !== STORAGE_KEY || !event.newValue) return;

      try {
        const slide = parseSlideMessage(JSON.parse(event.newValue), slides);
        if (slide) handler.current(slide.id, slide.step, joining);
      } catch {
        // Ignore malformed localStorage payloads from older tabs or manual edits.
      }
    };

    let channel = null;
    if ('BroadcastChannel' in window) {
      channel = new BroadcastChannel(CHANNEL_NAME);
      channel.addEventListener('message', handleMessage);
    }

    window.addEventListener('storage', handleStorage);
    try {
      if (!hydrated.current) {
        hydrated.current = true;
        handleStorage({ key: STORAGE_KEY, newValue: window.localStorage.getItem(STORAGE_KEY) }, true);
      }
    } catch {
      // Storage can be unavailable in embedded contexts.
    }
    return () => {
      channel?.removeEventListener('message', handleMessage);
      channel?.close();
      window.removeEventListener('storage', handleStorage);
    };
  }, [enabled]);
}
