import '@/slides/engine/presentation.css';

import { useLayoutEffect, useRef } from 'react';

import { cn } from '@/lib/utils';
import { applyMotionBuild } from '@/slides/engine/motionBuild';
import { SlideModeProvider } from '@/slides/engine/SlideModeContext';
import { SlidePositionProvider } from '@/slides/engine/SlidePositionContext';
import { useContainerScale } from '@/slides/engine/useContainerScale';
import { slides } from '@/slides/slides';

const DESIGN_WIDTH = 1280;
const DESIGN_HEIGHT = 720;
const FROZEN_MODES = ['thumbnail', 'overview', 'print'];

export default function SlideStage({ slide, mode = 'canvas', borderColor, className = '', build, onBuildSize }) {
  const { Component } = slide;
  const { containerRef, scale } = useContainerScale(DESIGN_WIDTH, DESIGN_HEIGHT);
  const frozen = FROZEN_MODES.includes(mode);
  const surfaceRef = useRef(null);

  useLayoutEffect(() => {
    if (frozen || !surfaceRef.current) return;
    const total = applyMotionBuild(surfaceRef.current, build);
    onBuildSize?.(total);
  });

  return (
    <div
      ref={containerRef}
      className={cn('relative flex h-full w-full items-center justify-center overflow-hidden', className)}
    >
      <div
        ref={surfaceRef}
        className={cn(
          'presentation-stage-surface flex-shrink-0 bg-[var(--slides-slate-950)]',
          frozen && 'presentation-frozen',
          borderColor && 'presentation-stage-border'
        )}
        style={{
          width: DESIGN_WIDTH,
          height: DESIGN_HEIGHT,
          transform: `scale(${scale})`,
          transformOrigin: 'center center',
          '--presentation-stage-border': borderColor,
          '--presentation-stage-scale': scale,
        }}
      >
        <SlideModeProvider mode={mode}>
          <SlidePositionProvider number={slides.findIndex((entry) => entry.id === slide.id) + 1} total={slides.length}>
            <Component />
          </SlidePositionProvider>
        </SlideModeProvider>
      </div>
    </div>
  );
}
