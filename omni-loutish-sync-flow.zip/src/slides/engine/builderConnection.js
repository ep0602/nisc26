// Match the Builder bridge's parent policy; user-controlled base44.app origins are excluded.
const TRUSTED_PARENTS = [
  /^https?:\/\/localhost(:\d+)?$/,
  /^https?:\/\/127\.0\.0\.1(:\d+)?$/,
  /^https:\/\/([a-zA-Z0-9-]+\.)*base44\.com$/,
  /^https:\/\/([a-zA-Z0-9-]+\.)*velino\.org$/,
];
let connection = null;

function isTrusted(origin) {
  return TRUSTED_PARENTS.some((pattern) => pattern.test(origin));
}

function parentOrigin() {
  if (connection?.parent === window.parent) return connection.origin;
  try {
    return window.location.ancestorOrigins?.[0] || new URL(document.referrer).origin;
  } catch {}
  return null;
}

export function builderOrigin() {
  if (window.parent === window) return null;
  const origin = parentOrigin();
  return origin && isTrusted(origin) ? origin : null;
}

export function acceptBuilderMessage(event) {
  if (window.parent === window || event.source !== window.parent || !isTrusted(event.origin)) return false;
  connection = { parent: window.parent, origin: event.origin };
  return true;
}
