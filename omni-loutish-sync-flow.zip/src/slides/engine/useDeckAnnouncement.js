import { useEffect, useRef } from 'react';

import { slideMarkup } from '@/slides/engine/slideMarkup';
import { slides } from '@/slides/slides';
import { acceptBuilderMessage, builderOrigin } from './builderConnection';
import { getSpeakerNotes, subscribeToSpeakerNotes } from './speakerNotes';

const DECK_MESSAGE_TYPE = 'presentation:deck';
const DECK_MESSAGE_VERSION = 1;
const REQUEST_DECK_MESSAGE_TYPE = 'presentation:request-deck';
const SLIDE_MODULE_PATTERN = /\/slides\/(?!speaker-notes\.json(?:$|\?))/;

const slideHashCache = new WeakMap();
let hotRevision = 0;

function hashString(text) {
  let hash = 0x811c9dc5;
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index);
    hash = (hash * 0x01000193) >>> 0;
  }
  return hash.toString(16).padStart(8, '0');
}

function slideHash(slide, index) {
  let markupHash;
  try {
    markupHash = hashString(slideMarkup(slide, index));
  } catch {
    markupHash = hashString(`${slide.id}:${slide.title}:${slide.subtitle ?? ''}`);
  }
  return hotRevision ? `${markupHash}-${hotRevision}` : markupHash;
}

function slideHashes() {
  let hashes = slideHashCache.get(slides);
  if (!hashes) {
    hashes = new Map(slides.map((slide, index) => [slide.id, slideHash(slide, index)]));
    slideHashCache.set(slides, hashes);
  }
  return hashes;
}

function currentIdFromLocation() {
  return (
    window.location.pathname.match(/^\/(?:slides|present)\/([a-z0-9-]+)/)?.[1] ?? slides[0]?.id ?? null
  );
}

export function postDeck(currentId) {
  const targetOrigin = builderOrigin();
  if (!targetOrigin) return;

  const hashes = slideHashes();
  window.parent.postMessage(
    {
      type: DECK_MESSAGE_TYPE,
      version: DECK_MESSAGE_VERSION,
      slides: slides.map((slide) => ({
        id: slide.id, title: slide.title, subtitle: slide.subtitle,
        hash: hashes.get(slide.id), speakerNotes: getSpeakerNotes(slide),
      })),
      currentId,
      motion: 1,
      motionClicks: 1,
    },
    targetOrigin
  );
}

if (import.meta.hot) {
  import.meta.hot.on('vite:beforeUpdate', (payload) => {
    if (payload.updates?.some((update) => SLIDE_MODULE_PATTERN.test(update.path ?? ''))) {
      hotRevision += 1;
    }
  });
  import.meta.hot.on('vite:afterUpdate', () => {
    slideHashCache.delete(slides);
    postDeck(currentIdFromLocation());
  });
}

export function useDeckAnnouncement(currentId) {
  const currentIdRef = useRef(currentId);
  currentIdRef.current = currentId;

  useEffect(() => {
    postDeck(currentId);
  }, [currentId]);

  useEffect(() => {
    function handleMessage(event) {
      if (!acceptBuilderMessage(event)) return;

      const data = event.data;
      if (typeof data !== 'object' || data === null) return;

      const { type, version } = data;
      if (type !== REQUEST_DECK_MESSAGE_TYPE) return;
      if (version !== undefined && version !== DECK_MESSAGE_VERSION) return;

      postDeck(currentIdRef.current);
    }

    const unsubscribe = subscribeToSpeakerNotes(() => postDeck(currentIdRef.current));
    window.addEventListener('message', handleMessage);
    return () => {
      unsubscribe();
      window.removeEventListener('message', handleMessage);
    };
  }, []);
}
