import { useEffect, useRef, useState } from 'react';

import { acceptBuilderMessage } from '@/slides/engine/builderConnection';
import { slides } from '@/slides/slides';

const CAPTURE_LIFETIME_MS = 35_000;
const MAX_PENDING_CAPTURES = 8;
const REQUEST_ID_PATTERN = /^[a-zA-Z0-9-]{1,128}$/;
const SLIDE_ID_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

export function useCaptureStages() {
  const [captures, setCaptures] = useState([]);

  useEffect(() => {
    const pending = new Map();
    function release(requestId) {
      clearTimeout(pending.get(requestId));
      pending.delete(requestId);
      setCaptures((current) => current.filter((capture) => capture.requestId !== requestId));
    }
    function onMessage(event) {
      const { type, requestId, id } = event.data ?? {};
      if (type !== 'presentation:prepare-capture' && type !== 'presentation:release-capture') return;
      if (!acceptBuilderMessage(event) || typeof requestId !== 'string' || !REQUEST_ID_PATTERN.test(requestId)) return;
      if (type === 'presentation:release-capture') {
        release(requestId);
        return;
      }
      if (pending.has(requestId)) return;
      if (pending.size >= MAX_PENDING_CAPTURES || typeof id !== 'string' || id.length > 64 ||
          !SLIDE_ID_PATTERN.test(id) || !slides.some((slide) => slide.id === id)) {
        event.source.postMessage({ type: 'presentation:capture-ready', requestId, elementId: null }, event.origin);
        return;
      }
      // The editor can disappear before sending release; abandoned stages must still expire.
      pending.set(requestId, setTimeout(() => release(requestId), CAPTURE_LIFETIME_MS));
      setCaptures((current) => [...current, {
        id, requestId, elementId: `presentation-capture-${requestId}`, origin: event.origin, parent: event.source,
      }]);
    }
    window.addEventListener('message', onMessage);
    return () => {
      window.removeEventListener('message', onMessage);
      pending.forEach(clearTimeout);
    };
  }, []);

  return captures;
}

export function useCaptureStageRef(capture) {
  const ref = useRef(null);
  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    const announce = () => {
      const { width, height } = element.getBoundingClientRect();
      if (width <= 0 || height <= 0) return;
      capture.parent.postMessage({
        type: 'presentation:capture-ready', requestId: capture.requestId, elementId: capture.elementId,
      }, capture.origin);
      observer.disconnect();
    };
    const observer = new ResizeObserver(announce);
    observer.observe(element);
    announce();
    return () => observer.disconnect();
  }, [capture]);
  return ref;
}
