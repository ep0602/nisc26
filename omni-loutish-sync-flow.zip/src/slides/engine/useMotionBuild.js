import { useState } from 'react';

const INTERACTIVE = 'a, button, input, textarea, select, summary, [role="button"], [contenteditable="true"]';
const fresh = (id) => ({ id, step: 0, settled: 0, key: 0 });
const shown = (id, step, key = 0) => ({ id, step, settled: step + 1, key });

export function useMotionBuild(slideId, { next, prev, previousId, enabled = true }) {
  const [state, setState] = useState(() => fresh(slideId));
  const [view, setView] = useState({ id: slideId, enabled });
  const [size, setSize] = useState({ id: null, total: 0 });
  if (view.id !== slideId || view.enabled !== enabled) {
    setView({ id: slideId, enabled });
    setState(state.id === slideId && state.arriving && view.enabled === enabled ? { ...state, arriving: false } : fresh(slideId));
  }
  const build = state.id === slideId ? state : fresh(slideId);
  const ready = size.id === slideId;
  const total = ready ? size.total : 0;
  const step = Math.min(build.step, total);

  const advance = () => {
    if (enabled && step < total) setState({ ...build, step: step + 1 });
    else next();
  };

  return {
    build: enabled ? build : undefined,
    stageKey: `${slideId}:${build.key}`,
    step,
    ready,
    onBuildSize: (count) => setSize((current) => (current.id === slideId && current.total === count ? current : { id: slideId, total: count })),
    next: advance,
    prev: () => {
      if (enabled && step > 0) {
        setState(shown(slideId, step - 1, build.key + 1));
        return;
      }
      if (enabled && previousId) setState({ id: previousId, step: Infinity, settled: Infinity, key: 0, arriving: true });
      prev();
    },
    advanceOnClick: (event) => {
      if (!(event.target instanceof Element) || !event.target.closest(INTERACTIVE)) advance();
    },
    follow: (id, target, joining) => {
      if (id !== slideId) setState({ ...(target || joining ? shown(id, target) : fresh(id)), arriving: true });
      else if (joining) setState(shown(id, target, build.key + 1));
      else if (target === step + 1) setState({ ...build, step: target });
      else if (target !== step) setState(shown(id, target, build.key + 1));
    },
  };
}
