import { createContext, useContext } from 'react';

const SlidePositionContext = createContext({ number: 1, total: 1 });

/** @param {{ number: number, total: number, children?: import('react').ReactNode }} props */
export function SlidePositionProvider({ number, total, children }) {
  return <SlidePositionContext.Provider value={{ number, total }}>{children}</SlidePositionContext.Provider>;
}

export function useSlidePosition() {
  return useContext(SlidePositionContext);
}
