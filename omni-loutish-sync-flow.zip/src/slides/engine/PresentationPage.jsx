import '../theme.css';
import { presentationLocale, ui } from '../strings';
import { useLocation } from 'react-router-dom';
import { slides } from '../slides';
import EditorView from './EditorView';
import PresentView from './PresentView';
import SpeakerView from './SpeakerView';
import PrintView from './PrintView';

export default function PresentationPage() {
  const { pathname } = useLocation();
  const View = pathname === '/print' ? PrintView
    : pathname === '/speaker' || pathname.startsWith('/speaker/') ? SpeakerView
    : pathname === '/present' || pathname.startsWith('/present/') ? PresentView : EditorView;
  return (
    <div lang={presentationLocale.lang} dir={presentationLocale.dir}>
      {slides.length ? <View /> : <p role="status">{ui.noSlides}</p>}
    </div>
  );
}
