import SlideStage from '@/slides/engine/SlideStage';
import { useLazyVisible } from '@/slides/engine/useLazyVisible';

// Renders the real slide component (no screenshots), so slides must be
// render-pure — see the render-purity rule in AGENTS.md.
export default function SlideThumbnail({ slide, mode = 'thumbnail' }) {
  const { ref, isVisible } = useLazyVisible();

  return (
    <div ref={ref} className="aspect-video w-full overflow-hidden pointer-events-none" inert="" tabIndex={-1}>
      {isVisible ? (
        <SlideStage slide={slide} mode={mode} />
      ) : (
        <div className="flex h-full w-full items-center justify-center bg-[var(--slides-slate-900)] px-2 text-center text-[10px] text-[var(--slides-slate-500)]">
          {slide.title}
        </div>
      )}
    </div>
  );
}
