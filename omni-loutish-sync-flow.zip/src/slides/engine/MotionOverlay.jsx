import { useEffect, useRef, useState } from 'react';

import { acceptBuilderMessage } from './builderConnection';
import {
  describeElement, elementsAt, isEditableLocation, MOTION_EFFECTS, MOTION_VERSION,
  motionState, pickTarget, postMotion, previewElements,
} from './motionElements';

const boxOf = (element) => {
  const { top, left, width, height } = element.getBoundingClientRect();
  return { top, left, width, height };
};

const isAnimating = (elements) => elements.some((element) => element.getAnimations({ subtree: true })
  .some((animation) => animation.playState === 'running' && animation.effect?.getComputedTiming().endTime !== Infinity));

const safeColor = (value) => (typeof value === 'string' && CSS.supports('color', value) ? value : undefined);

export default function MotionOverlay({ stageRef, slideId, onReplay }) {
  const [picking, setPicking] = useState(false);
  const [highlight, setHighlight] = useState(null);
  const [hover, setHover] = useState(null);
  const [color, setColor] = useState();
  const [, setTick] = useState(0);
  const slideRef = useRef(slideId);
  slideRef.current = slideId;

  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return undefined;
    let timer;
    const announce = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        postMotion('presentation:motion-state', motionState(stage, slideRef.current));
        setTick((tick) => tick + 1);
      }, 60);
    };
    const observer = new MutationObserver(announce);
    observer.observe(stage, {
      subtree: true, childList: true, attributes: true,
      attributeFilter: ['data-motion', 'data-motion-order', 'data-motion-pace', 'data-motion-start', 'data-source-location'],
    });
    const refresh = () => setTick((tick) => tick + 1);
    stage.addEventListener('animationend', refresh);
    stage.addEventListener('animationcancel', refresh);
    window.addEventListener('resize', refresh);
    announce();
    return () => {
      clearTimeout(timer);
      observer.disconnect();
      stage.removeEventListener('animationend', refresh);
      stage.removeEventListener('animationcancel', refresh);
      window.removeEventListener('resize', refresh);
    };
  }, [stageRef, slideId]);

  useEffect(() => {
    const onMessage = (event) => {
      const data = event.data;
      if (typeof data !== 'object' || data === null || data.version !== MOTION_VERSION) return;
      if (!String(data.type).startsWith('presentation:motion-') || !acceptBuilderMessage(event)) return;
      const stage = stageRef.current;
      if (!stage) return;
      if (data.type === 'presentation:motion-inspect') {
        postMotion('presentation:motion-state', motionState(stage, slideRef.current));
      } else if (data.type === 'presentation:motion-pick') {
        setPicking(data.enabled === true);
        setHover(null);
        setColor(safeColor(data.color));
      } else if (data.type === 'presentation:motion-highlight') {
        setHighlight(isEditableLocation(data.location) ? data.location : null);
        setColor(safeColor(data.color));
      } else if (data.type === 'presentation:motion-preview') {
        if (isEditableLocation(data.location) && MOTION_EFFECTS.includes(data.effect)) {
          previewElements(stage, data.location, data.effect, data.pace);
        } else onReplay((count) => count + 1);
        requestAnimationFrame(() => setTick((tick) => tick + 1));
      }
    };
    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, [stageRef, onReplay]);

  useEffect(() => {
    const stage = stageRef.current;
    if (!picking || !stage) return undefined;
    const stop = (event) => {
      event.preventDefault();
      event.stopPropagation();
    };
    const onMove = (event) => {
      const target = pickTarget(stage, event.clientX, event.clientY);
      setHover(target ? boxOf(target) : null);
    };
    const onClick = (event) => {
      stop(event);
      const target = pickTarget(stage, event.clientX, event.clientY);
      if (!target) return;
      setPicking(false);
      setHover(null);
      postMotion('presentation:motion-picked', { slideId: slideRef.current, element: describeElement(stage, target) });
    };
    const onKey = (event) => {
      if (event.key !== 'Escape') return;
      stop(event);
      setPicking(false);
      setHover(null);
      postMotion('presentation:motion-pick-end', { slideId: slideRef.current });
    };
    const onLeave = () => setHover(null);
    stage.classList.add('presentation-motion-picking');
    stage.addEventListener('pointermove', onMove, true);
    stage.addEventListener('pointerdown', stop, true);
    stage.addEventListener('click', onClick, true);
    stage.addEventListener('pointerleave', onLeave);
    window.addEventListener('keydown', onKey, true);
    return () => {
      stage.classList.remove('presentation-motion-picking');
      stage.removeEventListener('pointermove', onMove, true);
      stage.removeEventListener('pointerdown', stop, true);
      stage.removeEventListener('click', onClick, true);
      stage.removeEventListener('pointerleave', onLeave);
      window.removeEventListener('keydown', onKey, true);
    };
  }, [picking, stageRef]);

  const stage = stageRef.current;
  const highlighted = stage && highlight ? elementsAt(stage, highlight) : [];
  const animating = isAnimating(highlighted);
  const selected = highlighted.map(boxOf);
  const style = color ? { '--presentation-motion-color': color } : undefined;
  return (
    <>
      {selected.map((box, index) => (
        <div key={`selected-${index}`} className="presentation-motion-outline" data-selected=""
          data-hidden={animating ? '' : undefined} style={{ ...style, ...box }} />
      ))}
      {picking && hover && <div className="presentation-motion-outline" style={{ ...style, ...hover }} />}
    </>
  );
}
