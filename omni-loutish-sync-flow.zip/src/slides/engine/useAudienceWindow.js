import { useCallback, useRef } from 'react';

import { publishPresentationSlide } from '@/slides/engine/usePresentationSync';

export function useAudienceWindow(currentSlideId, step = 0) {
  const audienceWindowRef = useRef(null);

  return useCallback(() => {
    const path = `/present/${encodeURIComponent(currentSlideId)}?audience=1`;
    const existingWindow = audienceWindowRef.current;

    if (existingWindow && !existingWindow.closed) {
      existingWindow.location.href = path;
      existingWindow.focus();
    } else {
      audienceWindowRef.current = window.open(path, 'base44-presentation-audience');
    }

    publishPresentationSlide(currentSlideId, step);
  }, [currentSlideId, step]);
}
