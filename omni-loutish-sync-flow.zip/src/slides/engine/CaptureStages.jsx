import SlideStage from '@/slides/engine/SlideStage';
import { useCaptureStageRef, useCaptureStages } from '@/slides/engine/useCaptureStages';
import { slides } from '@/slides/slides';

const DESIGN_WIDTH = 1280;
const DESIGN_HEIGHT = 720;

function CaptureStage({ capture }) {
  const ref = useCaptureStageRef(capture);
  const slide = slides.find((entry) => entry.id === capture.id);

  if (!slide) return null;
  return (
    <div ref={ref} id={capture.elementId} style={{ width: DESIGN_WIDTH, height: DESIGN_HEIGHT }}>
      <SlideStage slide={slide} mode="thumbnail" />
    </div>
  );
}

export default function CaptureStages() {
  const captures = useCaptureStages();
  if (captures.length === 0) return null;

  return (
    <div aria-hidden="true" inert="" style={{ position: 'fixed', top: 0, left: -20000, pointerEvents: 'none' }}>
      {captures.map((capture) => <CaptureStage key={capture.requestId} capture={capture} />)}
    </div>
  );
}
