import { useCallback, useEffect, useState } from 'react';

function formatElapsed(seconds) {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}:${String(remainingSeconds).padStart(2, '0')}`;
}

export function usePresentationTimer() {
  const [startedAt, setStartedAt] = useState(() => Date.now());
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const intervalId = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(intervalId);
  }, []);

  const reset = useCallback(() => {
    const nextStart = Date.now();
    setStartedAt(nextStart);
    setNow(nextStart);
  }, []);

  return {
    elapsed: formatElapsed(Math.floor((now - startedAt) / 1000)),
    reset,
  };
}
