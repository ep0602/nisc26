import { useEffect } from 'react';

import { slideMarkup } from '@/slides/engine/slideMarkup';
import { slides } from '@/slides/slides';

const SLIDES_BEHIND = 1;
const SLIDES_AHEAD = 2;
const CSS_URL = /url\(\s*(?:"([^"]*)"|'([^']*)'|([^'")\s]+))\s*\)/g;
const preloadedUrls = new Set();

function slideImageUrls(slide, index) {
  let markup;
  try {
    markup = slideMarkup(slide, index);
  } catch {
    return [];
  }
  const page = new DOMParser().parseFromString(markup, 'text/html');
  const urls = Array.from(page.querySelectorAll('img[src]'), (img) => img.getAttribute('src'));
  page.querySelectorAll('[style]').forEach((element) => {
    for (const [, double, single, bare] of element.style.backgroundImage.matchAll(CSS_URL)) urls.push(double ?? single ?? bare);
  });
  return urls;
}

export function usePreloadNearbySlides(currentIndex) {
  useEffect(() => {
    for (let index = Math.max(0, currentIndex - SLIDES_BEHIND); index <= currentIndex + SLIDES_AHEAD; index += 1) {
      if (index === currentIndex || index >= slides.length) continue;
      for (const url of slideImageUrls(slides[index], index)) {
        if (!url || preloadedUrls.has(url)) continue;
        preloadedUrls.add(url);
        const image = new Image();
        image.src = url;
        image.decode().catch(() => {});
      }
    }
  }, [currentIndex]);
}
