import { useSyncExternalStore } from 'react';
import initialNotes from '../speaker-notes.json';

let notes = initialNotes;
const listeners = new Set();

export function getSpeakerNotes(slide) {
  const value = Object.hasOwn(notes, slide.id) ? notes[slide.id] : slide.speakerNotes;
  return Array.isArray(value) ? value.filter((note) => typeof note === 'string') : [];
}

export function subscribeToSpeakerNotes(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function useSpeakerNotes(slide) {
  useSyncExternalStore(subscribeToSpeakerNotes, () => notes, () => notes);
  return getSpeakerNotes(slide);
}

if (import.meta.hot) {
  import.meta.hot.accept('../speaker-notes.json', (module) => {
    notes = module.default;
    for (const listener of listeners) listener();
  });
}
