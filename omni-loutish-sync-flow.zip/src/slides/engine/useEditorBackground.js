import { useEffect, useState } from 'react';
import { acceptBuilderMessage } from './builderConnection';

export function useEditorBackground() {
  const [colors, setColors] = useState({});

  useEffect(() => {
    const onMessage = (event) => {
      const data = event.data;
      if (data?.type !== 'presentation:editor-background' || data.version !== 1) return;
      if (!acceptBuilderMessage(event)) return;
      if (typeof data.color !== 'string' || !CSS.supports('color', data.color)) return;
      const borderColor = typeof data.borderColor === 'string' && CSS.supports('color', data.borderColor) ? data.borderColor : undefined;
      setColors({ backgroundColor: data.color, borderColor });
    };
    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, []);

  return colors;
}
