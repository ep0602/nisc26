import { ui } from '../strings';
import { useSpeakerNotes } from './speakerNotes';
import { useEffect } from 'react';
import { ExternalLink, MonitorUp, RotateCcw, SkipBack, SkipForward } from 'lucide-react';

import { slides } from '@/slides/slides';
import BackToSlides from '@/slides/engine/BackToSlides';
import SlideStage from '@/slides/engine/SlideStage';
import SlideThumbnail from '@/slides/engine/SlideThumbnail';
import { useAudienceWindow } from '@/slides/engine/useAudienceWindow';
import { useMotionBuild } from '@/slides/engine/useMotionBuild';
import { usePresentationKeys } from '@/slides/engine/usePresentationKeys';
import { usePresentationRouteNav } from '@/slides/engine/usePresentationRouteNav';
import { publishPresentationSlide } from '@/slides/engine/usePresentationSync';
import { usePresentationTimer } from '@/slides/engine/usePresentationTimer';

export default function SpeakerView() {
  const { currentSlide, currentIndex, next, prev, first, last, goToId } = usePresentationRouteNav('/speaker');
  const nextSlide = slides[Math.min(slides.length - 1, currentIndex + 1)];
  const motion = useMotionBuild(currentSlide.id, { next, prev, previousId: slides[currentIndex - 1]?.id });
  const openAudienceWindow = useAudienceWindow(currentSlide.id, motion.step);
  const { elapsed, reset } = usePresentationTimer();
  const notes = useSpeakerNotes(currentSlide);

  useEffect(() => {
    if (motion.ready) publishPresentationSlide(currentSlide.id, motion.step);
  }, [currentSlide.id, motion.ready, motion.step]);

  usePresentationKeys({
    onNext: motion.next,
    onPrev: motion.prev,
    onFirst: first,
    onLast: last,
  });

  return (
    <div className="presentation-speaker grid grid-cols-1 bg-[var(--slides-slate-950)] text-[var(--slides-slate-100)] lg:grid-cols-[minmax(0,1fr)_380px]">
      <main className="flex min-h-0 min-w-0 flex-col gap-4 p-4 md:p-6">
        <BackToSlides slideId={currentSlide.id} />
        <div className="flex shrink-0 flex-wrap items-center justify-between gap-3">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-[var(--slides-slate-500)]">
              {ui.slidePosition(currentIndex + 1, slides.length)}
            </p>
            <h1 className="text-xl font-semibold text-[var(--slides-slate-100)]">{currentSlide.title}</h1>
            <p className="mt-1 text-sm text-[var(--slides-slate-500)]">{ui.speakerControls}</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={motion.prev}
              aria-label={ui.previousSlide}
              className="rounded-md bg-[var(--slides-slate-800)] p-2 text-[var(--slides-slate-200)] hover:bg-[var(--slides-slate-700)]"
            >
              <SkipBack className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={motion.next}
              aria-label={ui.nextSlide}
              className="rounded-md bg-[var(--slides-indigo-500)] p-2 text-[var(--slides-white)] hover:bg-[var(--slides-indigo-400)]"
            >
              <SkipForward className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="presentation-speaker-stage aspect-video min-h-0 overflow-hidden rounded-lg border border-[var(--slides-slate-800)] bg-[var(--slides-slate-900)]">
          <SlideStage key={motion.stageKey} slide={currentSlide} mode="present" build={motion.build} onBuildSize={motion.onBuildSize} />
        </div>

        <nav aria-label={ui.slides} className="presentation-speaker-navigation grid shrink-0 grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-5">
          {slides.map((slide, index) => (
            <button
              key={slide.id}
              type="button"
              onClick={() => goToId(slide.id)}
              aria-current={slide.id === currentSlide.id ? 'true' : undefined}
              className="rounded-md border border-[var(--slides-slate-800)] bg-[var(--slides-slate-900)] px-3 py-2 text-left text-sm text-[var(--slides-slate-300)] hover:border-[var(--slides-slate-700)] aria-current:border-[var(--slides-indigo-400)] aria-current:text-[var(--slides-white)]"
            >
              <span className="mr-2 font-mono text-xs text-[var(--slides-slate-500)]">{index + 1}</span>
              <span className="align-middle">{slide.title}</span>
            </button>
          ))}
        </nav>
      </main>

      <aside className="presentation-speaker-sidebar flex min-h-0 min-w-0 flex-col gap-4 border-t border-[var(--slides-slate-800)] bg-[var(--slides-slate-900-70)] p-4 lg:border-l lg:border-t-0 md:p-6">
        <section className="flex shrink-0 items-center justify-between rounded-lg border border-[var(--slides-slate-800)] bg-[var(--slides-slate-950)] p-4">
          <div>
            <p className="text-xs uppercase tracking-widest text-[var(--slides-slate-500)]">{ui.timer}</p>
            <p className="font-mono text-3xl text-[var(--slides-slate-100)]">{elapsed}</p>
          </div>
          <button
            type="button"
            onClick={reset}
            className="inline-flex items-center gap-2 rounded-md bg-[var(--slides-slate-800)] px-3 py-2 text-sm text-[var(--slides-slate-200)] hover:bg-[var(--slides-slate-700)]"
          >
            <RotateCcw className="h-4 w-4" />
            {ui.reset}
          </button>
        </section>

        <section className="shrink-0 rounded-lg border border-[var(--slides-slate-800)] bg-[var(--slides-slate-950)] p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="inline-flex items-center gap-2 text-sm font-semibold text-[var(--slides-slate-100)]">
              <MonitorUp className="h-4 w-4 text-[var(--slides-indigo-300)]" />
              {ui.audienceTab}
            </h2>
            <button
              type="button"
              onClick={openAudienceWindow}
              className="inline-flex items-center gap-2 rounded-md bg-[var(--slides-indigo-500)] px-3 py-2 text-sm font-medium text-[var(--slides-white)] hover:bg-[var(--slides-indigo-400)]"
            >
              <ExternalLink className="h-4 w-4" />
              {ui.openTab}
            </button>
          </div>
          <p className="text-sm text-[var(--slides-slate-400)]">
            {ui.audienceHelp}
          </p>
        </section>

        <section className="presentation-speaker-notes min-h-0 flex-1 rounded-lg border border-[var(--slides-slate-800)] bg-[var(--slides-slate-950)] p-4">
          <h2 className="mb-3 text-sm font-semibold text-[var(--slides-slate-100)]">{ui.speakerNotes}</h2>
          {notes.length > 0 ? (
            <ul className="space-y-3 break-words text-sm leading-6 text-[var(--slides-slate-300)]">
              {notes.map((note, index) => (
                <li key={`${index}-${note}`} className="whitespace-pre-wrap border-l-2 border-[var(--slides-indigo-400)] pl-3">
                  {note}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-[var(--slides-slate-500)]">{ui.noNotes}</p>
          )}
        </section>

        <section className="shrink-0 rounded-lg border border-[var(--slides-slate-800)] bg-[var(--slides-slate-950)] p-4">
          <p className="mb-2 text-xs uppercase tracking-widest text-[var(--slides-slate-500)]">{ui.next}</p>
          <SlideThumbnail slide={nextSlide} mode="overview" />
          <p className="mt-2 text-sm font-medium text-[var(--slides-slate-200)]">{nextSlide.title}</p>
        </section>
      </aside>
    </div>
  );
}
