import { useEffect } from 'react';

import { slides } from '@/slides/slides';
import { acceptBuilderMessage } from './builderConnection';

const NAVIGATE_MESSAGE_TYPE = 'presentation:navigate';
const NAVIGATE_MESSAGE_VERSION = 1;

export function usePresentationNavigationListener(onNavigate) {
  useEffect(() => {
    function handleMessage(event) {
      if (!acceptBuilderMessage(event)) return;

      const data = event.data;
      if (typeof data !== 'object' || data === null) return;

      const { type, version, id } = data;
      if (type !== NAVIGATE_MESSAGE_TYPE) return;
      if (version !== undefined && version !== NAVIGATE_MESSAGE_VERSION) return;
      if (typeof id !== 'string') return;
      if (!slides.some((slide) => slide.id === id)) return;

      onNavigate(id);
    }

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [onNavigate]);
}
