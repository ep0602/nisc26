import { ui } from '../strings';
import { slides } from '@/slides/slides';
import SlideStage from '@/slides/engine/SlideStage';
import BackToSlides from '@/slides/engine/BackToSlides';
import { usePrintReturnSlide } from '@/slides/engine/usePrintReturnSlide';

export default function PrintView() {
  const returnSlide = usePrintReturnSlide();
  return (
    <div className="min-h-screen bg-[var(--slides-slate-100)]">
      <div className="presentation-print-hint sticky top-0 z-10 flex flex-wrap items-center gap-x-6 gap-y-2 border-b border-[var(--slides-slate-200)] bg-[var(--slides-white)] px-4 py-2 text-sm text-[var(--slides-slate-600)]">
        <BackToSlides slideId={returnSlide.id} />
        <p>{ui.printHelp}</p>
      </div>

      <div className="presentation-print-list flex flex-col items-center gap-8 p-8">
        {slides.map((slide) => (
          <div
            key={slide.id}
            className="presentation-print-page aspect-video w-full max-w-4xl overflow-hidden bg-[var(--slides-white)] shadow-lg"
          >
            <SlideStage slide={slide} mode="print" />
          </div>
        ))}
      </div>
    </div>
  );
}
