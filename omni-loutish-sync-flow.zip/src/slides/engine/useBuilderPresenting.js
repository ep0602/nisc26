import { useEffect, useState } from 'react';

import { acceptBuilderMessage } from './builderConnection';

const PRESENTING_MESSAGE_TYPE = 'presentation:presenting';
const PRESENTING_MESSAGE_VERSION = 1;

export function useBuilderPresenting() {
  const [presenting, setPresenting] = useState(false);

  useEffect(() => {
    function handleMessage(event) {
      const data = event.data;
      if (typeof data !== 'object' || data === null || data.type !== PRESENTING_MESSAGE_TYPE) return;
      if (data.version !== PRESENTING_MESSAGE_VERSION || typeof data.presenting !== 'boolean') return;
      if (acceptBuilderMessage(event)) setPresenting(data.presenting);
    }

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  return presenting;
}
