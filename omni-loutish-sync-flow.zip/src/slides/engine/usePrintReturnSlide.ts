import { useSearchParams } from 'react-router-dom';
import { slides } from '../slides';

export function usePrintReturnSlide() {
  const [searchParams] = useSearchParams();
  return slides.find((slide) => slide.id === searchParams.get('slide')) ?? slides[0];
}
