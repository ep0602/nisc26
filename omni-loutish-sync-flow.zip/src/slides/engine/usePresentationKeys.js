import { useEffect } from 'react';

function isTypingTarget(target) {
  if (!target) return false;
  const tag = target.tagName;
  return tag === 'INPUT' || tag === 'TEXTAREA' || target.isContentEditable;
}

/**
 * @param {{ onNext?: () => void, onPrev?: () => void, onFirst?: () => void,
 * onLast?: () => void, onEscape?: () => void,
 * enabled?: boolean }} options
 */
export function usePresentationKeys({
  onNext,
  onPrev,
  onFirst,
  onLast,
  onEscape,
  enabled = true,
}) {
  useEffect(() => {
    if (!enabled) return;

    const handleKeyDown = (event) => {
      if (isTypingTarget(event.target)) return;

      switch (event.key) {
        case 'ArrowRight':
        case 'ArrowDown':
        case ' ':
        case 'PageDown':
          onNext?.();
          break;
        case 'ArrowLeft':
        case 'ArrowUp':
        case 'PageUp':
          onPrev?.();
          break;
        case 'Home':
          onFirst?.();
          break;
        case 'End':
          onLast?.();
          break;
        case 'Escape':
          onEscape?.();
          break;
        default:
          return;
      }
      event.preventDefault();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [enabled, onNext, onPrev, onFirst, onLast, onEscape]);
}
