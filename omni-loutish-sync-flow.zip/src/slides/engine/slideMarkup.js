import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';

import { SlideModeProvider } from '@/slides/engine/SlideModeContext';
import { SlidePositionProvider } from '@/slides/engine/SlidePositionContext';
import { slides } from '@/slides/slides';

export function slideMarkup(slide, index) {
  return renderToStaticMarkup(
    createElement(SlideModeProvider, { mode: 'thumbnail' },
      createElement(SlidePositionProvider, { number: index + 1, total: slides.length }, createElement(slide.Component)))
  );
}
