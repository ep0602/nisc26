import { builderOrigin } from './builderConnection';

export const MOTION_VERSION = 1;
export const MOTION_EFFECTS = ['fade', 'rise', 'from-left', 'from-right', 'zoom'];
export const MOTION_PACES = ['slow', 'medium', 'fast'];
const LOCATION_PATTERN = /^[^\s:"'<>]+:\d+:\d+$/;
const ENGINE_PREFIX = 'src/slides/engine/';
const MAX_TEXT = 80;
const MAX_ELEMENTS = 60;

export function isEditableLocation(location) {
  return typeof location === 'string' && location.length <= 512 && LOCATION_PATTERN.test(location) &&
    !location.startsWith(ENGINE_PREFIX);
}

export function elementsAt(stage, location) {
  return Array.from(stage.querySelectorAll(`[data-source-location="${CSS.escape(location)}"]`));
}

function nearestEditable(stage, target) {
  let element = target instanceof Element ? target.closest('[data-source-location]') : null;
  while (element && stage.contains(element) && element !== stage) {
    if (element instanceof HTMLElement && isEditableLocation(element.dataset.sourceLocation)) return element;
    element = element.parentElement?.closest('[data-source-location]') ?? null;
  }
  return null;
}

const areaOf = (element) => {
  const { width, height } = element.getBoundingClientRect();
  return width * height;
};

const contains = (element, x, y) => {
  const { left, right, top, bottom } = element.getBoundingClientRect();
  return x >= left && x <= right && y >= top && y <= bottom;
};

export function pickTarget(stage, x, y) {
  const surface = stage.querySelector('.presentation-stage-surface');
  const backdrop = surface ? areaOf(surface) * 0.9 : Infinity;
  let fallback = null;
  for (const hit of document.elementsFromPoint(x, y)) {
    if (!stage.contains(hit)) continue;
    const element = nearestEditable(stage, hit);
    if (!element) continue;
    if (areaOf(element) < backdrop) return element;
    fallback ??= element;
  }
  const covering = Array.from(stage.querySelectorAll('[data-source-location]'))
    .filter((element) => element instanceof HTMLElement && isEditableLocation(element.dataset.sourceLocation) && contains(element, x, y) && areaOf(element) < backdrop)
    .sort((a, b) => areaOf(a) - areaOf(b));
  return covering[0] ?? fallback;
}

export function describeElement(stage, element) {
  const location = element.dataset.sourceLocation;
  const effect = MOTION_EFFECTS.includes(element.dataset.motion) ? element.dataset.motion : null;
  const order = Number(element.dataset.motionOrder);
  const text = element.tagName === 'IMG' ? element.getAttribute('alt') ?? '' : element.innerText || element.textContent || '';
  return {
    location,
    tag: element.tagName.toLowerCase(),
    text: text.replace(/\s+/g, ' ').trim().slice(0, MAX_TEXT),
    effect,
    order: effect ? (Number.isInteger(order) && order >= 1 && order <= 10 ? order : 1) : null,
    pace: effect ? (MOTION_PACES.includes(element.dataset.motionPace) ? element.dataset.motionPace : 'medium') : null,
    start: effect && element.dataset.motionStart === 'click' ? 'click' : null,
    count: elementsAt(stage, location).length,
  };
}

export function animatedElements(stage) {
  const seen = new Set();
  const elements = [];
  for (const element of stage.querySelectorAll('[data-motion][data-source-location]')) {
    const location = element.dataset.sourceLocation;
    if (seen.has(location) || !isEditableLocation(location) || !MOTION_EFFECTS.includes(element.dataset.motion)) continue;
    seen.add(location);
    elements.push(describeElement(stage, element));
    if (elements.length >= MAX_ELEMENTS) break;
  }
  return elements;
}

export const motionState = (stage, slideId) => ({
  slideId, elements: animatedElements(stage), sourceMapped: stage.querySelector('[data-source-location]') !== null,
});

export function postMotion(type, payload) {
  const origin = builderOrigin();
  if (origin) window.parent.postMessage({ type, version: MOTION_VERSION, ...payload }, origin);
}

export function previewElements(stage, location, effect, pace) {
  for (const element of elementsAt(stage, location)) {
    element.removeAttribute('data-motion');
    element.setAttribute('data-motion-preview', '');
    if (pace === 'slow' || pace === 'fast') element.setAttribute('data-motion-pace', pace);
    else element.removeAttribute('data-motion-pace');
    void element.offsetWidth;
    element.setAttribute('data-motion', effect);
  }
}
