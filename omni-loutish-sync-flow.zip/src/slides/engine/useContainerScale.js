import { useEffect, useRef, useState } from 'react';

export function useContainerScale(designWidth, designHeight) {
  const containerRef = useRef(null);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const updateScale = () => {
      const { clientWidth, clientHeight } = el;
      if (!clientWidth || !clientHeight) return;
      setScale(Math.min(clientWidth / designWidth, clientHeight / designHeight));
    };

    updateScale();
    const observer = new ResizeObserver(updateScale);
    observer.observe(el);
    return () => observer.disconnect();
  }, [designWidth, designHeight]);

  return { containerRef, scale };
}
