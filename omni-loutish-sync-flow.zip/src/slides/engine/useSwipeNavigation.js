import { useRef } from 'react';

const SWIPE_THRESHOLD = 50;

export function useSwipeNavigation({ onSwipeLeft, onSwipeRight }) {
  const startX = useRef(null);

  const onTouchStart = (event) => {
    startX.current = event.touches[0].clientX;
  };

  const onTouchEnd = (event) => {
    if (startX.current === null) return;
    const deltaX = event.changedTouches[0].clientX - startX.current;
    startX.current = null;

    if (deltaX <= -SWIPE_THRESHOLD) {
      onSwipeLeft?.();
    } else if (deltaX >= SWIPE_THRESHOLD) {
      onSwipeRight?.();
    }
  };

  return { onTouchStart, onTouchEnd };
}
