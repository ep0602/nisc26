import { createContext, useContext } from 'react';

const SlideModeContext = createContext('canvas');

/** @param {{ mode: string, children?: import('react').ReactNode }} props */
export function SlideModeProvider({ mode, children }) {
  return <SlideModeContext.Provider value={mode}>{children}</SlideModeContext.Provider>;
}

export function useSlideMode() {
  return useContext(SlideModeContext);
}
