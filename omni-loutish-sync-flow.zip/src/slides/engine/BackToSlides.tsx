import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ui } from '../strings';

export default function BackToSlides({ slideId }: { slideId: string }) {
  return (
    <Link to={`/slides/${encodeURIComponent(slideId)}`} className="presentation-back-link">
      <ArrowLeft aria-hidden="true" className="h-4 w-4 rtl:rotate-180" />
      {ui.backToSlides}
    </Link>
  );
}
