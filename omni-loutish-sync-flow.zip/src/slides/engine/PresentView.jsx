import { ui } from '../strings';
import { useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';

import { slides } from '@/slides/slides';
import SlideStage from '@/slides/engine/SlideStage';
import { useFullscreen } from '@/slides/engine/useFullscreen';
import { useMotionBuild } from '@/slides/engine/useMotionBuild';
import { usePresentationKeys } from '@/slides/engine/usePresentationKeys';
import { usePresentationRouteNav } from '@/slides/engine/usePresentationRouteNav';
import { usePreloadNearbySlides } from '@/slides/engine/usePreloadNearbySlides';
import { usePresentationSync } from '@/slides/engine/usePresentationSync';
import { useSwipeNavigation } from '@/slides/engine/useSwipeNavigation';

export default function PresentView() {
  const [searchParams] = useSearchParams();
  const isAudience = searchParams.get('audience') === '1';
  const routeOptions = isAudience ? { search: '?audience=1' } : undefined;
  const { currentSlide, currentIndex, next, prev, first, last, goToId } = usePresentationRouteNav(
    '/present',
    routeOptions
  );
  const { containerRef, isFullscreen, enterFullscreen, exitFullscreen } = useFullscreen();
  const motion = useMotionBuild(currentSlide.id, { next, prev, previousId: slides[currentIndex - 1]?.id });
  const swipeHandlers = useSwipeNavigation({
    onSwipeLeft: isAudience ? undefined : motion.next,
    onSwipeRight: isAudience ? undefined : motion.prev,
  });
  const navigate = useNavigate();

  const handleExit = useCallback(() => {
    exitFullscreen();
    navigate(`/slides/${currentSlide.id}`);
  }, [currentSlide.id, exitFullscreen, navigate]);

  usePresentationSync((id, step, joining) => {
    motion.follow(id, step, joining);
    if (id !== currentSlide.id) goToId(id);
  }, isAudience);
  usePreloadNearbySlides(currentIndex);
  usePresentationKeys({
    onNext: motion.next,
    onPrev: motion.prev,
    onFirst: first,
    onLast: last,
    onEscape: handleExit,
    enabled: !isAudience,
  });

  return (
    <div
      ref={containerRef}
      className="relative flex h-screen w-screen items-center justify-center bg-[var(--slides-slate-950)]"
      onClick={isAudience ? undefined : motion.advanceOnClick}
      {...swipeHandlers}
    >
      <SlideStage key={motion.stageKey} slide={currentSlide} mode="present" build={motion.build} onBuildSize={motion.onBuildSize} />

      {!isAudience && (
        <div className="absolute bottom-4 left-4 font-mono text-sm text-[var(--slides-slate-500)]">
          {currentIndex + 1} / {slides.length}
        </div>
      )}

      {!isAudience && (
        <div className="absolute top-4 right-4 flex gap-2">
          {!isFullscreen && (
            <button
              type="button"
              onClick={enterFullscreen}
              className="rounded-md bg-[var(--slides-slate-800-80)] px-3 py-1.5 text-sm text-[var(--slides-slate-200)] hover:bg-[var(--slides-slate-700)]"
            >
              {ui.fullscreen}
            </button>
          )}
          <button
            type="button"
            onClick={handleExit}
            aria-label={ui.exitPresentation}
            className="rounded-md bg-[var(--slides-slate-800-80)] px-3 py-1.5 text-sm text-[var(--slides-slate-200)] hover:bg-[var(--slides-slate-700)]"
          >
            {ui.exit}
          </button>
        </div>
      )}
    </div>
  );
}
