import { useCallback, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

import { slides } from '@/slides/slides';

export function usePresentationRouteNav(basePath, options = {}) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { search = '' } = options;
  const index = slides.findIndex((slide) => slide.id === id);
  const currentIndex = index === -1 ? 0 : index;
  const pathForSlide = useCallback((slideId) => `${basePath}/${encodeURIComponent(slideId)}${search}`, [basePath, search]);

  useEffect(() => {
    if (index === -1) {
      navigate(pathForSlide(slides[0].id), { replace: true });
    }
  }, [index, navigate, pathForSlide]);

  const goToIndex = useCallback(
    (nextIndex) => {
      const clamped = Math.max(0, Math.min(slides.length - 1, nextIndex));
      navigate(pathForSlide(slides[clamped].id));
    },
    [navigate, pathForSlide]
  );

  const goToId = useCallback((targetId) => navigate(pathForSlide(targetId)), [navigate, pathForSlide]);

  return {
    currentIndex,
    currentSlide: slides[currentIndex],
    goToIndex,
    goToId,
    next: () => goToIndex(currentIndex + 1),
    prev: () => goToIndex(currentIndex - 1),
    first: () => goToIndex(0),
    last: () => goToIndex(slides.length - 1),
  };
}
