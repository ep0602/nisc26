import { useEffect, useRef, useState } from 'react';

import CaptureStages from '@/slides/engine/CaptureStages';
import MotionOverlay from '@/slides/engine/MotionOverlay';
import SlideStage from '@/slides/engine/SlideStage';
import { useBuilderPresenting } from '@/slides/engine/useBuilderPresenting';
import { useDeckAnnouncement } from '@/slides/engine/useDeckAnnouncement';
import { usePresentationKeys } from '@/slides/engine/usePresentationKeys';
import { usePresentationNavigationListener } from '@/slides/engine/usePresentationNavigationListener';
import { usePresentationRouteNav } from '@/slides/engine/usePresentationRouteNav';
import { usePreloadNearbySlides } from '@/slides/engine/usePreloadNearbySlides';
import { publishPresentationSlide } from '@/slides/engine/usePresentationSync';
import { useSwipeNavigation } from '@/slides/engine/useSwipeNavigation';
import { useEditorBackground } from '@/slides/engine/useEditorBackground';
import { useMotionBuild } from '@/slides/engine/useMotionBuild';
import { slides } from '@/slides/slides';

export default function EditorView() {
  const { backgroundColor, borderColor } = useEditorBackground();
  const { currentSlide, currentIndex, next, prev, first, last, goToId } = usePresentationRouteNav('/slides');
  const presenting = useBuilderPresenting();
  const motion = useMotionBuild(currentSlide.id, { next, prev, previousId: slides[currentIndex - 1]?.id, enabled: presenting });
  const swipeHandlers = useSwipeNavigation({ onSwipeLeft: motion.next, onSwipeRight: motion.prev });
  const stageRef = useRef(null);
  const [replay, setReplay] = useState(0);

  useEffect(() => {
    publishPresentationSlide(currentSlide.id);
  }, [currentSlide.id]);

  useDeckAnnouncement(currentSlide.id);
  usePreloadNearbySlides(currentIndex);
  usePresentationNavigationListener(goToId);

  usePresentationKeys({ onNext: motion.next, onPrev: motion.prev, onFirst: first, onLast: last });

  return (
    <div style={{ backgroundColor }} className="flex h-screen w-screen flex-col overflow-hidden bg-[var(--slides-slate-950)]"
      onClick={presenting ? motion.advanceOnClick : undefined} {...swipeHandlers}>
      <main ref={stageRef} className="relative min-h-0 min-w-0 flex-1 overflow-hidden p-4 md:p-8">
        <SlideStage key={`${replay}:${presenting}:${motion.stageKey}`} slide={currentSlide} mode="canvas" borderColor={borderColor}
          build={motion.build} onBuildSize={motion.onBuildSize} />
      </main>
      <MotionOverlay stageRef={stageRef} slideId={currentSlide.id} onReplay={setReplay} />
      <CaptureStages />
    </div>
  );
}
