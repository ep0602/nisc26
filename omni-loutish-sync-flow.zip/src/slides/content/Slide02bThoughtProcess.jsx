import React from 'react';
import {
  Mic,
  Database,
  BookOpen,
  Layout,
  ArrowRight,
  Trophy,
  TrendingUp,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import SlideChrome from '../components/SlideChrome';

export default function Slide02bThoughtProcess() {
  return (
    <SlideChrome
      variant="light"
      sectionLabel="METHODOLOGY · HUMAN + ACADEMIC + MULTI-AI WORKFLOW"
      sourceNote="Co-Created via Live Brainstorming, Consensus, University-Supplied Databases, Multi-AI Synthesis & Base44"
    >
      {/* Clean Header */}
      <div className="mb-4">
        <h2 className="font-heading text-[28px] font-extrabold tracking-tight text-[#0B1F3A] leading-tight">
          Understand How to Solve the Problem Through AI
        </h2>
        <p className="text-[14px] text-[#1F2937] mt-1 border-l-[3px] border-[#2563EB] pl-3">
          From live brainstorming and{' '}
          <span className="font-semibold text-[#0B1F3A]">
            independent research (Consensus &amp; university databases)
          </span>{' '}
          to an interactive <span className="font-semibold text-[#0B1F3A]">Base44 platform</span>.
        </p>
      </div>

      {/* 4-Step Visual Journey */}
      <div
        data-motion="rise"
        data-motion-order="1"
        className="flex-1 grid grid-cols-4 gap-3.5 items-stretch"
      >
        {/* Step 1: Conference Room Brainstorm */}
        <div className="relative bg-white rounded-2xl border-2 border-[#2563EB] ring-4 ring-blue-500/10 shadow-md p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="w-11 h-11 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center">
                <Mic className="w-5 h-5 text-[#2563EB]" />
              </div>
              <span className="font-mono text-[11px] font-bold text-[#2563EB] bg-blue-50 px-2.5 py-0.5 rounded-full">
                STEP 01
              </span>
            </div>
            <h3 className="font-heading text-base font-extrabold text-[#0B1F3A] mb-1.5 leading-snug">
              Conference Room Brainstorm
            </h3>
            <p className="text-[12.5px] text-slate-600 leading-relaxed">
              Had <strong>Claude, Gemini, and AI browsers</strong> listen live to our team
              brainstorm—filtering raw ideas to surface the strongest path forward.
            </p>
          </div>

          <div className="pt-2.5 border-t border-slate-100 flex flex-wrap gap-1">
            <span className="px-2 py-0.5 rounded bg-slate-100 text-[10px] font-mono font-semibold text-slate-700">
              Claude
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-100 text-[10px] font-mono font-semibold text-slate-700">
              Gemini
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-100 text-[10px] font-mono font-semibold text-slate-700">
              AI Browsers
            </span>
          </div>

          <div className="flex absolute -right-2.5 top-1/2 -translate-y-1/2 z-10 w-5 h-5 rounded-full bg-[#2563EB] text-white items-center justify-center shadow">
            <ArrowRight className="w-3 h-3" />
          </div>
        </div>

        {/* Step 2: Article & Data Filtering */}
        <div className="relative bg-white rounded-2xl border-2 border-[#06B6D4] ring-4 ring-cyan-500/10 shadow-md p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="w-11 h-11 rounded-xl bg-cyan-50 border border-cyan-200 flex items-center justify-center">
                <Database className="w-5 h-5 text-[#06B6D4]" />
              </div>
              <span className="font-mono text-[11px] font-bold text-cyan-700 bg-cyan-50 px-2.5 py-0.5 rounded-full">
                STEP 02
              </span>
            </div>
            <h3 className="font-heading text-base font-extrabold text-[#0B1F3A] mb-1.5 leading-snug">
              Multi-AI Data Synthesis
            </h3>
            <p className="text-[12.5px] text-slate-600 leading-relaxed">
              Pulled metrics from the supporting case-study articles and filtered them across{' '}
              <strong>multiple AI platforms</strong> to connect ideas with hard evidence.
            </p>
          </div>

          <div className="pt-2.5 border-t border-slate-100 flex flex-wrap gap-1">
            <span className="px-2 py-0.5 rounded bg-cyan-50 text-[10px] font-mono font-semibold text-cyan-800">
              Supported Articles
            </span>
            <span className="px-2 py-0.5 rounded bg-cyan-50 text-[10px] font-mono font-semibold text-cyan-800">
              Cross-AI Filter
            </span>
          </div>

          <div className="flex absolute -right-2.5 top-1/2 -translate-y-1/2 z-10 w-5 h-5 rounded-full bg-[#06B6D4] text-white items-center justify-center shadow">
            <ArrowRight className="w-3 h-3" />
          </div>
        </div>

        {/* Step 3: Independent Outside Research */}
        <div className="relative bg-white rounded-2xl border-2 border-indigo-600 ring-4 ring-indigo-500/10 shadow-md p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="w-11 h-11 rounded-xl bg-indigo-50 border border-indigo-200 flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-indigo-600" />
              </div>
              <span className="font-mono text-[11px] font-bold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-full">
                STEP 03
              </span>
            </div>
            <h3 className="font-heading text-base font-extrabold text-[#0B1F3A] mb-1.5 leading-snug">
              Independent Outside Research
            </h3>
            <p className="text-[12.5px] text-slate-600 leading-relaxed">
              Conducted independent academic research via <strong>Consensus</strong> and{' '}
              <strong>university-supplied databases</strong> to validate coaching &amp; buyer
              psychology.
            </p>
          </div>

          <div className="pt-2.5 border-t border-slate-100 flex flex-wrap gap-1">
            <span className="px-2 py-0.5 rounded bg-indigo-50 text-[10px] font-mono font-semibold text-indigo-800">
              Consensus
            </span>
            <span className="px-2 py-0.5 rounded bg-indigo-50 text-[10px] font-mono font-semibold text-indigo-800">
              University Databases
            </span>
          </div>

          <div className="flex absolute -right-2.5 top-1/2 -translate-y-1/2 z-10 w-5 h-5 rounded-full bg-indigo-600 text-white items-center justify-center shadow">
            <ArrowRight className="w-3 h-3" />
          </div>
        </div>

        {/* Step 4: Base44 Website & Coaching App */}
        <div className="relative bg-white rounded-2xl border-2 border-[#10B981] ring-4 ring-emerald-500/10 shadow-md p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="w-11 h-11 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center">
                <Layout className="w-5 h-5 text-[#10B981]" />
              </div>
              <span className="font-mono text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full">
                STEP 04
              </span>
            </div>
            <h3 className="font-heading text-base font-extrabold text-[#0B1F3A] mb-1.5 leading-snug">
              Built Live on Base44
            </h3>
            <p className="text-[12.5px] text-slate-600 leading-relaxed">
              Built an interactive platform with{' '}
              <strong>progress bars, weekly competition, and KPI tracking</strong> so reps turn
              weaknesses into strengths.
            </p>
          </div>

          <div className="pt-2.5 border-t border-slate-100 flex flex-wrap gap-1">
            <span className="px-2 py-0.5 rounded bg-emerald-50 text-[10px] font-mono font-semibold text-emerald-800">
              Base44 App
            </span>
            <span className="px-2 py-0.5 rounded bg-emerald-50 text-[10px] font-mono font-semibold text-emerald-800">
              KPIs &amp; Gamification
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Outcome Strip: What Our Prototype Proves */}
      <div
        data-motion="rise"
        data-motion-order="2"
        className="mt-4 rounded-2xl bg-[#0B1F3A] text-white px-6 py-3.5 flex items-center justify-between gap-6 shadow-md"
      >
        <div className="flex items-center gap-2.5 shrink-0">
          <Sparkles className="w-5 h-5 text-cyan-300" />
          <span className="font-mono text-xs font-bold tracking-wider text-cyan-300 uppercase">
            WHAT WE BUILT IN BASE44:
          </span>
        </div>

        <div className="flex-1 grid grid-cols-3 gap-4 text-xs">
          <div className="flex items-center gap-2.5 bg-white/[0.06] rounded-xl px-3.5 py-2 border border-white/10">
            <TrendingUp className="w-4 h-4 text-[#38BDF8] shrink-0" />
            <span>
              <strong className="text-white">Progress Bars:</strong> Track weekly rep growth &amp;
              weaknesses
            </span>
          </div>

          <div className="flex items-center gap-2.5 bg-white/[0.06] rounded-xl px-3.5 py-2 border border-white/10">
            <Trophy className="w-4 h-4 text-amber-300 shrink-0" />
            <span>
              <strong className="text-white">Weekly Competition:</strong> Drives excitement to
              improve
            </span>
          </div>

          <div className="flex items-center gap-2.5 bg-white/[0.06] rounded-xl px-3.5 py-2 border border-white/10">
            <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
            <span>
              <strong className="text-white">Deal-Closing KPIs:</strong> Pinpoints exact skills to
              win
            </span>
          </div>
        </div>
      </div>
    </SlideChrome>
  );
}