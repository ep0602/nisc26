import React from 'react';
import { Trophy, Flame, Award, TrendingUp, Star, CheckCircle2 } from 'lucide-react';
import SlideChrome from '../components/SlideChrome';

export default function Slide07GamificationReports() {
  return (
    <SlideChrome
      variant="light"
      sectionLabel="ADOPTION ENGINE · WEEKLY BRIEFS & REWARDS"
      activeStep={6}
      sourceNote="Behavioral Reinforcement: Rewards Skill Mastery & Consensus Instead of Spam Volume"
    >
      {/* A & B Message Hierarchy */}
      <div className="mb-3">
        <h2 className="font-heading text-[26px] font-extrabold tracking-tight text-[#0B1F3A] leading-tight">
          Weekly 2-Way AI Check-Ins &amp; Smart Gamification
        </h2>
        <p className="text-[13.5px] text-[#1F2937] mt-1 border-l-[3px] border-[#2563EB] pl-3">
          End-of-week <span className="font-semibold text-[#0B1F3A]">two-way AI interviews</span>{' '}
          and skill rewards sustain &gt;85% active adoption.
        </p>
      </div>

      {/* 68% Dual UI Visual Workspace */}
      <div className="flex-1 grid grid-cols-12 gap-5 items-stretch overflow-hidden">
        {/* Left 6 Cols: Weekly AI Performance Report UI Mockup */}
        <div
          data-motion="rise"
          data-motion-order="1"
          className="col-span-6 bg-white rounded-xl border border-slate-200 shadow-sm p-4 flex flex-col justify-between"
        >
          <div className="flex items-center justify-between pb-2.5 border-b border-slate-100">
            <div>
              <span className="font-mono text-[10px] font-bold text-[#2563EB] uppercase">
                EVERY MONDAY · PERSONAL BRIEF
              </span>
              <h3 className="font-heading text-sm font-extrabold text-[#0B1F3A]">
                Weekly AI Growth Report
              </h3>
            </div>
            <div className="text-right">
              <span className="px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 font-mono text-xs font-bold text-[#10B981]">
                Score: 91 / 100 (+9)
              </span>
            </div>
          </div>

          {/* Strength vs Weakness Cards */}
          <div className="grid grid-cols-2 gap-2.5 my-2">
            <div className="p-2.5 rounded-lg bg-emerald-50/60 border border-emerald-200">
              <p className="font-mono text-[10px] font-bold text-emerald-700 uppercase">
                TOP STRENGTH
              </p>
              <p className="text-xs font-bold text-[#0B1F3A] mt-0.5">
                Stakeholder Mapping
              </p>
              <p className="text-[11px] text-slate-600 mt-0.5">
                6.8 buyers/deal (+42% vs. team).
              </p>
            </div>
            <div className="p-2.5 rounded-lg bg-amber-50/70 border border-amber-200">
              <p className="font-mono text-[10px] font-bold text-amber-700 uppercase">
                FOCUS GAP
              </p>
              <p className="text-xs font-bold text-[#0B1F3A] mt-0.5">
                CFO Price Defense
              </p>
              <p className="text-[11px] text-slate-600 mt-0.5">
                Assigned 12-min CFO ROI Sim.
              </p>
            </div>
          </div>

          {/* 8-Week Skill Growth Bar Chart (Instant Readability) */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <span className="font-mono text-[10px] font-semibold text-slate-500 uppercase">
                8-WEEK SKILL SCORE CLIMB (64 → 91)
              </span>
              <span className="font-mono text-[11px] font-bold text-[#10B981]">
                Quota Pace: 116%
              </span>
            </div>
            <div className="flex items-end justify-between gap-2 h-20 pt-2 px-1">
              <div className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full h-7 rounded-t bg-slate-300" />
                <span className="text-[9.5px] text-slate-500 font-mono">W1</span>
              </div>
              <div className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full h-8 rounded-t bg-slate-300" />
                <span className="text-[9.5px] text-slate-500 font-mono">W2</span>
              </div>
              <div className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full h-10 rounded-t bg-blue-300" />
                <span className="text-[9.5px] text-slate-500 font-mono">W3</span>
              </div>
              <div className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full h-11 rounded-t bg-blue-400" />
                <span className="text-[9.5px] text-slate-500 font-mono">W4</span>
              </div>
              <div className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full h-12 rounded-t bg-[#2563EB]" />
                <span className="text-[9.5px] text-slate-500 font-mono">W5</span>
              </div>
              <div className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full h-14 rounded-t bg-[#06B6D4]" />
                <span className="text-[9.5px] text-slate-500 font-mono">W6</span>
              </div>
              <div className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full h-16 rounded-t bg-[#06B6D4]" />
                <span className="text-[9.5px] text-slate-500 font-mono">W7</span>
              </div>
              <div className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full h-[70px] rounded-t bg-[#10B981]" />
                <span className="text-[9.5px] text-[#10B981] font-bold font-mono">W8</span>
              </div>
            </div>
          </div>

          {/* End-of-Week 2-Way AI Interview Box */}
          <div className="p-2.5 rounded-xl bg-blue-50/80 border border-blue-200 text-[11px] space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[9.5px] font-bold text-[#2563EB] uppercase">
                FRIDAY 2-WAY AI INTERVIEW (LISTENS &amp; ADAPTS)
              </span>
              <CheckCircle2 className="w-3.5 h-3.5 text-[#2563EB] shrink-0" />
            </div>
            <p className="text-[#0B1F3A] font-medium">
              “Did this help you? What can <strong>you</strong> work on—and what can <strong>I</strong>{' '}
              improve for you?”
            </p>
          </div>
        </div>

        {/* Right 6 Cols: Gamification & Behavioral Reward Engine */}
        <div
          data-motion="rise"
          data-motion-order="2"
          className="col-span-6 bg-[#0B1F3A] text-white rounded-xl p-4 shadow-md flex flex-col justify-between"
        >
          <div className="flex items-center justify-between pb-2.5 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Trophy className="w-4 h-4 text-[#F59E0B]" />
              <div>
                <h3 className="font-heading text-sm font-extrabold text-white">
                  Gamification &amp; Behavioral Reward Engine
                </h3>
                <p className="text-[10.5px] text-slate-300">
                  Scores high-value habits (Sim Mastery · CSPI Delta · Consensus), never spam volume
                </p>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded bg-amber-400/20 border border-amber-400/40 font-mono text-[10px] text-amber-300">
              89% ENGAGEMENT
            </span>
          </div>

          {/* Visual Team Leaderboard Bars */}
          <div className="rounded-xl bg-white/[0.05] border border-white/10 p-3 space-y-2">
            <div className="flex items-center justify-between text-[10px] font-mono text-cyan-300 uppercase">
              <span>SKILL LEADERBOARD (NOT EMAIL VOLUME)</span>
              <span>XP SCORE</span>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-0.5">
                <span className="font-bold text-amber-300">#1 Elena V.</span>
                <span className="font-mono text-[11px] text-white">2,480 XP</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full">
                <div className="w-[96%] h-full bg-amber-400 rounded-full" />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-0.5">
                <span className="font-semibold text-white">#2 Marcus K.</span>
                <span className="font-mono text-[11px] text-cyan-300">2,310 XP</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full">
                <div className="w-[88%] h-full bg-[#06B6D4] rounded-full" />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-0.5">
                <span className="font-semibold text-white">#3 Maya R. (Most Improved)</span>
                <span className="font-mono text-[11px] text-[#10B981]">2,190 XP</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full">
                <div className="w-[82%] h-full bg-[#10B981] rounded-full" />
              </div>
            </div>
          </div>

          {/* Badges, Milestones & Weekly Challenges */}
          <div className="grid grid-cols-3 gap-2.5 my-1">
            <div className="p-2.5 rounded-lg bg-[#112A4E] border border-cyan-400/30 text-center">
              <Award className="w-4 h-4 text-cyan-300 mx-auto mb-1" />
              <p className="text-[11px] font-bold text-white">Committee Pro</p>
              <p className="text-[9.5px] text-slate-300">5+ Buyers Mapped</p>
            </div>
            <div className="p-2.5 rounded-lg bg-[#112A4E] border border-[#10B981]/30 text-center">
              <Flame className="w-4 h-4 text-[#10B981] mx-auto mb-1" />
              <p className="text-[11px] font-bold text-white">Sim Champion</p>
              <p className="text-[9.5px] text-slate-300">90%+ Skeptical CFO</p>
            </div>
            <div className="p-2.5 rounded-lg bg-[#112A4E] border border-amber-400/30 text-center">
              <Star className="w-4 h-4 text-amber-300 mx-auto mb-1" />
              <p className="text-[11px] font-bold text-white">Bias Breaker</p>
              <p className="text-[9.5px] text-slate-300">Zero Stalled Anchors</p>
            </div>
          </div>

          {/* Weekly Challenge + Micro-Bonus */}
          <div className="p-2.5 rounded-lg bg-[#10B981]/15 border border-[#10B981]/40 flex items-center justify-between text-[11px]">
            <div>
              <span className="font-mono text-[9.5px] text-[#10B981] uppercase block">
                WEEKLY CHALLENGE
              </span>
              <span className="text-white font-medium">
                2 Pre-Call Sims → Spot Bonus &amp; CRO Recognition
              </span>
            </div>
            <TrendingUp className="w-4 h-4 text-[#10B981] shrink-0" />
          </div>
        </div>
      </div>
    </SlideChrome>
  );
}