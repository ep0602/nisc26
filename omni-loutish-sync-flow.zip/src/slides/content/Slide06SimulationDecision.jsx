import React from 'react';
import { Users, ShieldAlert, Award, Sparkles, Eye } from 'lucide-react';
import SlideChrome from '../components/SlideChrome';

export default function Slide06SimulationDecision() {
  return (
    <SlideChrome
      variant="dark"
      sectionLabel="KEY DIFFERENTIATOR · PERSONA SIMULATOR & DEBIASING"
      activeStep={5}
      sourceNote="Gartner Benchmark: 13% → 40% Win Rate Using AI Prep 2x/Deal · Decision Science"
    >
      {/* A & B Message Hierarchy */}
      <div className="mb-3">
        <h2 className="font-heading text-[26px] font-extrabold tracking-tight text-white leading-tight">
          Persona Sales Simulator &amp; Bias Shield
        </h2>
        <p className="text-[13.5px] text-slate-200 mt-1 border-l-[3px] border-[#10B981] pl-3">
          Reps rehearse with <span className="text-cyan-300 font-semibold">CRM-cloned buyers</span>{' '}
          before live calls—while AI blocks cognitive bias and groupthink.
        </p>
      </div>

      {/* 70% Visual Workspace */}
      <div className="flex-1 grid grid-cols-12 gap-4 items-stretch overflow-hidden">
        {/* Left 7 Cols: Customer-Persona Sales Training Simulator */}
        <div
          data-motion="rise"
          data-motion-order="1"
          className="col-span-7 rounded-xl bg-gradient-to-b from-[#122C52] to-[#08172C] border border-cyan-400/30 p-4 flex flex-col justify-between"
        >
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-[#06B6D4]" />
              <h3 className="font-heading text-sm font-bold text-white">
                Dynamic Customer-Persona Roleplay Simulator
              </h3>
            </div>
            <span className="px-2.5 py-0.5 rounded bg-[#10B981]/20 border border-[#10B981]/50 font-mono text-[10px] font-bold text-[#10B981]">
              13% → 40% WIN RATE LIFT
            </span>
          </div>

          {/* 4 Targeted Simulation & Coaching Modes */}
          <div>
            <p className="font-mono text-[9.5px] text-cyan-300 uppercase mb-1.5">
              VOICE &amp; VIDEO AI BUYERS BUILT FROM LOST CALL TRANSCRIPTS (INDUSTRY · TITLE · PUSHBACK)
            </p>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="px-2.5 py-1.5 rounded-lg bg-[#2563EB]/25 border border-[#2563EB]/60 text-white">
                <strong className="text-cyan-300">1. Replay Losses:</strong> Voice/video buyer twins
              </div>
              <div className="px-2.5 py-1.5 rounded-lg bg-amber-500/15 border border-amber-400/40 text-white">
                <strong className="text-amber-300">2. Objection Drills:</strong> Fixes frozen speech &amp; price caves
              </div>
              <div className="px-2.5 py-1.5 rounded-lg bg-white/[0.06] border border-white/15 text-slate-200">
                <strong className="text-white">3. Discovery &amp; Value:</strong> Quantification &amp; reframing
              </div>
              <div className="px-2.5 py-1.5 rounded-lg bg-white/[0.06] border border-white/15 text-slate-200">
                <strong className="text-white">4. Vocal Soft Skills:</strong> Pacing, filler words &amp; cues
              </div>
            </div>
          </div>

          {/* Live Simulation Evaluation + Visual Win-Rate Jump */}
          <div className="grid grid-cols-12 gap-3 bg-[#071324] rounded-xl p-3.5 border border-white/10 items-center">
            {/* Left: Win-Rate Visual Jump Bar */}
            <div className="col-span-5 pr-3 border-r border-white/10 flex flex-col justify-between h-full">
              <span className="font-mono text-[10px] text-cyan-300 uppercase">
                WIN-RATE IMPACT (GARTNER)
              </span>
              <div className="flex items-end justify-around h-28 pt-3 pb-1 border-b border-white/10">
                <div className="flex flex-col items-center gap-1">
                  <span className="font-heading text-sm font-bold text-slate-400">13%</span>
                  <div className="w-11 h-7 rounded-t bg-slate-600" />
                </div>
                <div className="flex flex-col items-center gap-1">
                  <span className="font-heading text-base font-extrabold text-[#10B981]">40%</span>
                  <div className="w-11 h-20 rounded-t bg-gradient-to-t from-[#10B981] to-cyan-300 shadow-lg shadow-emerald-500/20" />
                </div>
              </div>
              <div className="grid grid-cols-2 text-center text-[10px] text-slate-300 pt-1">
                <span>No Prep</span>
                <span className="text-[#10B981] font-bold">2x AI Roleplay</span>
              </div>
            </div>

            {/* Right: Behavioral & Soft-Skills Scorecard */}
            <div className="col-span-7 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] text-slate-300 uppercase">
                  SOFT-SKILLS &amp; OBJECTION SCORE
                </span>
                <span className="font-mono text-xs font-bold text-[#10B981]">89 / 100</span>
              </div>

              <div className="space-y-1.5 text-xs">
                <div>
                  <div className="flex justify-between">
                    <span className="text-slate-200">Talk-to-Listen Ratio</span>
                    <span className="font-mono text-cyan-300">92%</span>
                  </div>
                  <div className="h-2 bg-white/10 rounded-full mt-0.5">
                    <div className="w-[92%] h-full bg-[#06B6D4] rounded-full" />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between">
                    <span className="text-slate-200">Holding Price (No Concessions)</span>
                    <span className="font-mono text-[#10B981]">87%</span>
                  </div>
                  <div className="h-2 bg-white/10 rounded-full mt-0.5">
                    <div className="w-[87%] h-full bg-[#10B981] rounded-full" />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between">
                    <span className="text-slate-200">Vocal Pacing &amp; Low Filler Words</span>
                    <span className="font-mono text-cyan-300">94%</span>
                  </div>
                  <div className="h-2 bg-white/10 rounded-full mt-0.5">
                    <div className="w-[94%] h-full bg-[#2563EB] rounded-full" />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between">
                    <span className="text-slate-200">Emotional Cues &amp; Discovery</span>
                    <span className="font-mono text-amber-300">84%</span>
                  </div>
                  <div className="h-2 bg-white/10 rounded-full mt-0.5">
                    <div className="w-[84%] h-full bg-[#F59E0B] rounded-full" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-300">
            <span>Grounded in Behavioral, Consumer &amp; Sales Psychology</span>
            <span className="font-mono text-cyan-300 flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> SAFE PRACTICE
            </span>
          </div>
        </div>

        {/* Right 5 Cols: Simplified Plain-English Bias & Team Traps Shield */}
        <div
          data-motion="rise"
          data-motion-order="2"
          className="col-span-5 flex flex-col justify-between gap-3"
        >
          {/* Cognitive Bias Shield */}
          <div className="flex-1 rounded-xl bg-white/[0.05] border border-white/15 p-4 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-[#F59E0B]" />
                <h3 className="font-heading text-xs font-bold text-white uppercase tracking-wide">
                  Blindspot &amp; Bias Detector
                </h3>
              </div>
              <span className="font-mono text-[10px] text-amber-300">10 BIASES TRACKED</span>
            </div>

            <div className="space-y-2 my-2 text-xs">
              <div className="p-2.5 rounded-lg bg-amber-500/15 border border-amber-400/40 flex items-center justify-between">
                <span className="font-semibold text-white">“Happy Ears” (Overconfidence)</span>
                <span className="font-mono text-[10px] text-amber-200">Flagged</span>
              </div>
              <div className="p-2.5 rounded-lg bg-rose-500/15 border border-rose-400/40 flex items-center justify-between">
                <span className="font-semibold text-white">Chasing Dead Deals (Sunk Cost)</span>
                <span className="font-mono text-[10px] text-rose-200">Blocked</span>
              </div>
              <div className="p-2.5 rounded-lg bg-white/[0.05] border border-white/10 flex items-center justify-between">
                <span className="font-semibold text-slate-200">First-Price Anchoring &amp; Framing</span>
                <span className="font-mono text-[10px] text-cyan-300">Coached</span>
              </div>
            </div>
          </div>

          {/* Team Dysfunction Shield */}
          <div className="rounded-xl bg-white/[0.05] border border-white/15 p-4">
            <div className="flex items-center justify-between mb-2.5">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-[#10B981]" />
                <h3 className="font-heading text-xs font-bold text-white uppercase tracking-wide">
                  Healthy Team Guardrails
                </h3>
              </div>
              <span className="font-mono text-[10px] text-[#10B981]">8 SAFEGUARDS</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <span className="p-2 rounded-lg bg-[#0B1F3A] border border-white/10 text-slate-200">
                ✓ Stops Groupthink
              </span>
              <span className="p-2 rounded-lg bg-[#0B1F3A] border border-white/10 text-slate-200">
                ✓ Prevents “Good Enough”
              </span>
              <span className="p-2 rounded-lg bg-[#0B1F3A] border border-white/10 text-slate-200">
                ✓ Breaks Tunnel Vision
              </span>
              <span className="p-2 rounded-lg bg-[#0B1F3A] border border-white/10 text-slate-200">
                ✓ Challenges Status Quo
              </span>
            </div>
          </div>
        </div>
      </div>
    </SlideChrome>
  );
}