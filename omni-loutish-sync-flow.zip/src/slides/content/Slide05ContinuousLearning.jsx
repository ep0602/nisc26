import React from 'react';
import { RefreshCw, TrendingUp, Users, CheckCircle2 } from 'lucide-react';
import SlideChrome from '../components/SlideChrome';

export default function Slide05ContinuousLearning() {
  return (
    <SlideChrome
      variant="light"
      sectionLabel="CLOSED-LOOP FLYWHEEL · MANAGER CSPI"
      activeStep={4}
      sourceNote="Gartner CSO Survey (n=229) · Comparative Sales Performance Index (CSPI)"
    >
      {/* A & B Message Hierarchy */}
      <div className="mb-3">
        <h2 className="font-heading text-[26px] font-extrabold tracking-tight text-[#0B1F3A] leading-tight">
          Closed-Deal Reviews &amp; Win vs. Loss Benchmarking
        </h2>
        <p className="text-[13.5px] text-[#1F2937] mt-1 border-l-[3px] border-[#10B981] pl-3">
          Managers + AI audit <span className="font-semibold text-[#0B1F3A]">closed deals instead of email counts</span>—benchmarking
          losses against similar Closed-Won deals.
        </p>
      </div>

      {/* 68% Visual Workspace */}
      <div className="flex-1 grid grid-cols-12 gap-5 items-stretch overflow-hidden">
        {/* Left 5 Cols: Clean 4-Stage Visual Flywheel */}
        <div
          data-motion="rise"
          data-motion-order="1"
          className="col-span-5 bg-white rounded-xl border border-slate-200 p-4 shadow-sm flex flex-col justify-between"
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <div className="flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-[#2563EB]" />
              <h3 className="font-heading text-sm font-bold text-[#0B1F3A]">
                Win vs. Loss Coaching Loop
              </h3>
            </div>
            <span className="font-mono text-[10px] text-[#10B981] font-semibold">KPI BENCHMARKED</span>
          </div>

          {/* Intuitive 4-Stage Cycle with Center Hub */}
          <div className="relative grid grid-cols-2 gap-3 my-3 flex-1 items-stretch">
            <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 flex flex-col justify-between">
              <span className="font-mono text-[10px] font-bold text-[#2563EB]">1 · AUDIT CALLS</span>
              <p className="font-heading text-sm font-bold text-[#0B1F3A]">Flag Slip-Ups</p>
              <p className="text-xs text-slate-600">Spots bad email/call moves</p>
            </div>

            <div className="p-3.5 rounded-xl bg-cyan-50/70 border border-cyan-200 flex flex-col justify-between">
              <span className="font-mono text-[10px] font-bold text-cyan-700">2 · COMPARE</span>
              <p className="font-heading text-sm font-bold text-[#0B1F3A]">Win vs. Loss</p>
              <p className="text-xs text-slate-600">Matches Closed-Won deals</p>
            </div>

            <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 flex flex-col justify-between">
              <span className="font-mono text-[10px] font-bold text-amber-700">4 · REFRAME</span>
              <p className="font-heading text-sm font-bold text-[#0B1F3A]">Build on Strengths</p>
              <p className="text-xs text-slate-600">Active listening &amp; I-O psych</p>
            </div>

            <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200 flex flex-col justify-between">
              <span className="font-mono text-[10px] font-bold text-emerald-700">3 · REPLAY LOSS</span>
              <p className="font-heading text-sm font-bold text-[#0B1F3A]">Custom AI Drill</p>
              <p className="text-xs text-slate-600">Targeted to KPI gaps</p>
            </div>

            {/* Center Badge */}
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
              <div className="px-3 py-1.5 rounded-full bg-[#0B1F3A] text-white border-2 border-white shadow-md text-center">
                <span className="font-mono text-[10px] font-bold text-cyan-300">
                  LOSS → WIN
                </span>
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 text-xs text-slate-600 flex items-center justify-between">
            <span>Compares lost transcripts to Closed-Won buyer twins</span>
            <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
          </div>
        </div>

        {/* Right 7 Cols: Visual Rep vs. Team Average Bar Comparison */}
        <div
          data-motion="rise"
          data-motion-order="2"
          className="col-span-7 bg-[#0B1F3A] text-white rounded-xl p-4 shadow-md flex flex-col justify-between"
        >
          <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
            <div>
              <h3 className="font-heading text-sm font-bold text-white">
                Friday Manager + AI Review: Closed Deals (Never Email Counts)
              </h3>
              <p className="text-[11px] text-slate-300">
                Benchmarks real deal outcomes &amp; assigns targeted drills for next week
              </p>
            </div>
            <span className="px-2.5 py-1 rounded bg-[#10B981]/20 border border-[#10B981]/50 font-mono text-[10px] text-[#10B981] font-semibold">
              4.3x PROFIT LIFT
            </span>
          </div>

          {/* 3 Visual Benchmark Bars (Rep vs. Team Average Marker) */}
          <div className="space-y-3 my-2">
            {/* Bar 1: Pipeline */}
            <div className="p-3 rounded-xl bg-white/[0.05] border border-white/10">
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-bold text-white">Active Deals (Maya: 32 vs. Team: 25)</span>
                <span className="px-2 py-0.5 rounded bg-[#10B981]/20 text-[#10B981] font-mono text-[10px] font-bold">
                  +28% AHEAD → PRAISE
                </span>
              </div>
              <div className="relative h-3 bg-white/10 rounded-full">
                <div className="w-[82%] h-full bg-[#10B981] rounded-full" />
                <div
                  className="absolute top-[-3px] left-[64%] w-1 h-[18px] bg-white rounded"
                  title="Team Average"
                />
              </div>
            </div>

            {/* Bar 2: Win Rate */}
            <div className="p-3 rounded-xl bg-white/[0.05] border border-white/10">
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-bold text-white">Win Rate (Maya: 19.5% vs. Goal: 25%)</span>
                <span className="px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 font-mono text-[10px] font-bold">
                  BEHIND → ASSIGN CFO ROLEPLAY
                </span>
              </div>
              <div className="relative h-3 bg-white/10 rounded-full">
                <div className="w-[50%] h-full bg-[#F59E0B] rounded-full" />
                <div
                  className="absolute top-[-3px] left-[64%] w-1 h-[18px] bg-white rounded"
                  title="Team Target"
                />
              </div>
            </div>

            {/* Bar 3: Deal Size */}
            <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-400/35">
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-bold text-white">Avg. Deal Size (Maya: $104K vs. Team: $120K)</span>
                <span className="px-2 py-0.5 rounded bg-cyan-400/20 text-cyan-300 font-mono text-[10px] font-bold">
                  GAP → UPSELL &amp; CROSS-SELL GUIDE
                </span>
              </div>
              <div className="relative h-3 bg-white/10 rounded-full">
                <div className="w-[55%] h-full bg-[#06B6D4] rounded-full" />
                <div
                  className="absolute top-[-3px] left-[64%] w-1 h-[18px] bg-white rounded"
                  title="Team Average"
                />
              </div>
              <p className="mt-2 text-[11.5px] text-cyan-200 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-cyan-300 shrink-0" />
                <span>
                  Directly shows reps <strong className="text-white">how to upsell &amp; cross-sell</strong>{' '}
                  by surfacing add-ons won in similar $120K+ deals.
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-300 pt-1">
            <span className="flex items-center gap-2">
              <span className="inline-block w-1 h-3.5 bg-white rounded" /> White line = Team Target
            </span>
            <span className="font-mono text-[#10B981]">Saves managers 4.2 hrs/wk</span>
          </div>
        </div>
      </div>
    </SlideChrome>
  );
}