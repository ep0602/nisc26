import React from 'react';
import { Lock, Cpu, CheckCircle2, ArrowRight } from 'lucide-react';
import SlideChrome from '../components/SlideChrome';

export default function Slide08PartnershipsRouter() {
  return (
    <SlideChrome
      variant="dark"
      sectionLabel="AI ECOSYSTEM · MODEL ROUTER ARCHITECTURE"
      activeStep={7}
      sourceNote="Multi-Model Orchestration: Zero Vendor Lock-In & 40% - 70% Lower Inference Cost"
    >
      <div className="flex-1 flex flex-col justify-center pb-6">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="font-heading text-[36px] font-extrabold tracking-tight text-white leading-tight mb-3">
            Smart AI Model Router
          </h2>
          <p className="text-[16px] text-slate-300">
            We don't rely on a single vendor. Our router picks the best model for every task in &lt;15ms—cutting costs by <span className="font-semibold text-[#10B981]">40% - 70%</span>.
          </p>
        </div>

        <div
          data-motion="rise"
          data-motion-order="1"
          className="flex items-center justify-center gap-8 px-6"
        >
          {/* Step 1: Data */}
          <div className="w-64 rounded-3xl bg-white/[0.04] border border-white/10 p-8 text-center flex flex-col items-center h-[300px] justify-center">
            <Lock className="w-12 h-12 text-slate-400 mb-6" />
            <h3 className="font-heading text-xl font-bold text-white mb-3">1. Your Data</h3>
            <p className="text-[14px] text-slate-400">CRM signals, call telemetry, and employee profiles.</p>
          </div>

          <ArrowRight className="w-10 h-10 text-slate-600 shrink-0" />

          {/* Step 2: Router */}
          <div className="w-80 rounded-3xl bg-gradient-to-b from-[#2563EB]/25 to-[#0B1F3A] border-2 border-[#06B6D4] p-8 text-center shadow-2xl relative flex flex-col items-center h-[340px] justify-center">
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-5 py-2 bg-[#10B981] rounded-full text-[12px] font-bold text-white tracking-wider shadow-lg shadow-emerald-900 whitespace-nowrap">
              -40% TO -70% COST
            </div>
            <Cpu className="w-16 h-16 text-cyan-300 mb-5" />
            <h3 className="font-heading text-2xl font-bold text-white mb-5">AI Router</h3>
            <div className="text-[14px] text-slate-300 space-y-4 w-full text-left bg-black/20 p-5 rounded-2xl border border-white/5">
              <div className="flex items-center justify-between"><span>Checks Cost</span> <CheckCircle2 className="w-5 h-5 text-[#10B981]" /></div>
              <div className="flex items-center justify-between"><span>Checks Speed</span> <CheckCircle2 className="w-5 h-5 text-[#10B981]" /></div>
              <div className="flex items-center justify-between"><span>Checks Accuracy</span> <CheckCircle2 className="w-5 h-5 text-[#10B981]" /></div>
            </div>
          </div>

          <ArrowRight className="w-10 h-10 text-slate-600 shrink-0" />

          {/* Step 3: Models */}
          <div className="w-72 space-y-4 flex flex-col h-[300px] justify-center">
            <div className="p-5 rounded-2xl bg-[#2563EB]/15 border border-[#2563EB]/40 flex items-center justify-between">
              <div>
                <h4 className="font-bold text-white text-[15px]">Frontier Models</h4>
                <p className="text-[13px] text-slate-400 mt-1">Deep strategy & roleplay</p>
              </div>
            </div>
            <div className="p-5 rounded-2xl bg-[#06B6D4]/15 border border-[#06B6D4]/40 flex items-center justify-between">
              <div>
                <h4 className="font-bold text-white text-[15px]">Enterprise Cloud</h4>
                <p className="text-[13px] text-slate-400 mt-1">CRM drafting & sync</p>
              </div>
            </div>
            <div className="p-5 rounded-2xl bg-[#10B981]/15 border border-[#10B981]/40 flex items-center justify-between">
              <div>
                <h4 className="font-bold text-white text-[15px]">Fast Open-Source</h4>
                <p className="text-[13px] text-slate-400 mt-1">Routine tone matching</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </SlideChrome>
  );
}