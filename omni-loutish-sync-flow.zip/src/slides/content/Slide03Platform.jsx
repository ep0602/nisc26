import React from 'react';
import {
  Brain,
  Target,
  BarChart3,
  Sparkles,
  CheckCircle2
} from 'lucide-react';
import SlideChrome from '../components/SlideChrome';

export default function Slide03Platform() {
  return (
    <SlideChrome
      variant="dark"
      sectionLabel="PLATFORM ARCHITECTURE · CORE SOLUTION"
      activeStep={2}
      sourceNote="Gartner SPIM (Strip · Stack · Sharpen) & Evidence-Based I-O Psychology"
    >
      <div className="flex-1 flex flex-col justify-center pb-8">
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-400/15 border border-cyan-300/30 mb-4">
            <Sparkles className="w-3 h-3 text-cyan-300" />
            <span className="font-mono text-[10px] font-semibold text-cyan-200 uppercase">
              ONE COMPOUNDING MEMORY CORE
            </span>
          </div>
          <h2 className="font-heading text-[32px] font-extrabold tracking-tight text-white leading-tight mb-3">
            The AI Workforce Intelligence Platform
          </h2>
          <p className="text-[15px] text-slate-300">
            Uniting three core intelligence engines with authentic voice matching and behavioral science.
          </p>
        </div>

        <div
          data-motion="rise"
          data-motion-order="1"
          className="grid grid-cols-3 gap-6"
        >
          {/* Pillar 1 */}
          <div className="rounded-3xl bg-gradient-to-b from-[#2563EB]/20 to-transparent border border-[#2563EB]/40 p-8 flex flex-col items-center text-center">
            <div className="w-20 h-20 rounded-2xl bg-[#2563EB]/30 flex items-center justify-center mb-6">
              <Brain className="w-10 h-10 text-[#38BDF8]" />
            </div>
            <h3 className="font-heading text-2xl font-bold text-white mb-3">1. Top-Rep AI Coach</h3>
            <p className="text-[14px] text-slate-300 leading-relaxed mb-8">
              Built on your best sellers' habits—analyzing call recordings and public client intel to reframe rep weaknesses.
            </p>
            <div className="mt-auto w-full space-y-3 text-left">
              <div className="flex items-center gap-3 text-[14px] text-slate-200">
                <CheckCircle2 className="w-5 h-5 text-[#38BDF8] shrink-0" /> Call + online buyer needs
              </div>
              <div className="flex items-center gap-3 text-[14px] text-slate-200">
                <CheckCircle2 className="w-5 h-5 text-[#38BDF8] shrink-0" /> Friday 2-way AI check-in
              </div>
            </div>
          </div>

          {/* Pillar 2 */}
          <div className="rounded-3xl bg-gradient-to-b from-[#06B6D4]/20 to-transparent border border-[#06B6D4]/40 p-8 flex flex-col items-center text-center">
            <div className="w-20 h-20 rounded-2xl bg-[#06B6D4]/30 flex items-center justify-center mb-6">
              <Target className="w-10 h-10 text-cyan-300" />
            </div>
            <h3 className="font-heading text-2xl font-bold text-white mb-3">2. Loss-Replay Simulator</h3>
            <p className="text-[14px] text-slate-300 leading-relaxed mb-8">
              Turns lost call transcripts into interactive voice &amp; video AI buyers matched by industry, title, and pushback.
            </p>
            <div className="mt-auto w-full space-y-3 text-left">
              <div className="flex items-center gap-3 text-[14px] text-slate-200">
                <CheckCircle2 className="w-5 h-5 text-cyan-300 shrink-0" /> Pacing, fillers &amp; talk ratio
              </div>
              <div className="flex items-center gap-3 text-[14px] text-slate-200">
                <CheckCircle2 className="w-5 h-5 text-cyan-300 shrink-0" /> Price &amp; objection drills
              </div>
            </div>
          </div>

          {/* Pillar 3 */}
          <div className="rounded-3xl bg-gradient-to-b from-[#10B981]/20 to-transparent border border-[#10B981]/40 p-8 flex flex-col items-center text-center">
            <div className="w-20 h-20 rounded-2xl bg-[#10B981]/30 flex items-center justify-center mb-6">
              <BarChart3 className="w-10 h-10 text-[#10B981]" />
            </div>
            <h3 className="font-heading text-2xl font-bold text-white mb-3">3. Closed-Deal Hub</h3>
            <p className="text-[14px] text-slate-300 leading-relaxed mb-8">
              Managers + AI review closed deals instead of email counts—benchmarking losses against similar Closed-Won deals.
            </p>
            <div className="mt-auto w-full space-y-3 text-left">
              <div className="flex items-center gap-3 text-[14px] text-slate-200">
                <CheckCircle2 className="w-5 h-5 text-[#10B981] shrink-0" /> Win vs. loss benchmarking
              </div>
              <div className="flex items-center gap-3 text-[14px] text-slate-200">
                <CheckCircle2 className="w-5 h-5 text-[#10B981] shrink-0" /> KPI-targeted coaching
              </div>
            </div>
          </div>
        </div>
      </div>
    </SlideChrome>
  );
}