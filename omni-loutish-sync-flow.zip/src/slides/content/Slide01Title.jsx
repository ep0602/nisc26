import React from 'react';
import {
  Brain,
  TrendingUp,
  Target,
  Sparkles,
  Award,
  ShieldCheck
} from 'lucide-react';
import { useSlidePosition } from '@/slides/engine/SlidePositionContext';

export default function Slide01Title() {
  const { number, total } = useSlidePosition();

  return (
    <div className="relative w-[1280px] h-[720px] overflow-hidden bg-[#0B1F3A] text-white font-body flex flex-col justify-between select-none">
      {/* Architectural Grid & Luminous Accents */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.05]"
        style={{
          backgroundImage:
            'linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)',
          backgroundSize: '48px 48px',
        }}
      />
      <div
        className="pointer-events-none absolute -top-32 right-12 w-[640px] h-[640px] rounded-full opacity-25"
        style={{
          background:
            'radial-gradient(circle, rgba(37,99,235,0.65) 0%, rgba(6,182,212,0.28) 42%, transparent 70%)',
        }}
      />
      <div
        className="pointer-events-none absolute -bottom-44 -left-20 w-[520px] h-[520px] rounded-full opacity-20"
        style={{
          background: 'radial-gradient(circle, rgba(16,185,129,0.4) 0%, transparent 68%)',
        }}
      />

      {/* Top Executive Bar */}
      <header className="relative z-10 flex items-center justify-between px-12 pt-7 pb-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#2563EB] to-[#06B6D4] flex items-center justify-center shadow-lg shadow-blue-500/25">
            <Brain className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="font-mono text-[11px] font-semibold tracking-[0.22em] text-cyan-300 uppercase">
              EXECUTIVE &amp; VENTURE BRIEFING
            </p>
            <p className="text-xs text-slate-300">
              Workforce Intelligence · Sales Excellence · Decision Science
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <span className="px-3 py-1 rounded-full bg-white/5 border border-white/15 text-[11px] font-mono text-cyan-300">
            ACS REFERENCE PILOT: 300 AEs
          </span>
          <span className="px-3 py-1 rounded-full bg-[#10B981]/15 border border-[#10B981]/40 text-[11px] font-mono text-[#10B981]">
            TURNKEY BUDGET &lt; $10,000
          </span>
        </div>
      </header>

      {/* Main Redesigned Center Content */}
      <main className="relative z-10 flex-1 px-16 py-12 flex flex-col justify-center items-center text-center">
        <div className="max-w-4xl mb-14 flex flex-col items-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#2563EB]/20 border border-[#2563EB]/50 mb-6">
            <Sparkles className="w-3.5 h-3.5 text-[#06B6D4]" />
            <span className="font-mono text-[11px] font-semibold tracking-wider text-cyan-200 uppercase">
              ADAPTIVE AI GROWTH AGENTS
            </span>
          </div>

          <h1 className="font-heading text-[60px] leading-[1.05] font-extrabold tracking-tight text-white mb-6">
            AI Workforce <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#38BDF8] via-[#06B6D4] to-[#10B981]">Intelligence</span> Platform
          </h1>

          <p className="text-[19px] leading-relaxed text-slate-300 max-w-2xl">
            Turning saved AI hours into personalized coaching, live buyer roleplay, and measurable
            revenue growth for the enterprise.
          </p>
        </div>

        {/* 3 Clean Massive KPIs */}
        <div className="grid grid-cols-3 gap-8 w-full max-w-5xl">
          <div className="p-8 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-sm flex flex-col items-center">
            <TrendingUp className="w-10 h-10 text-[#06B6D4] mb-4" />
            <p className="font-heading text-5xl font-extrabold text-white mb-2">4.8 hrs</p>
            <p className="text-[15px] font-medium text-slate-400">Reclaimed Time / Week</p>
          </div>
          <div className="p-8 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-sm flex flex-col items-center">
            <Target className="w-10 h-10 text-[#10B981] mb-4" />
            <p className="font-heading text-5xl font-extrabold text-[#10B981] mb-2">3.1x</p>
            <p className="text-[15px] font-medium text-slate-400">Win Rate Lift via Roleplay</p>
          </div>
          <div className="p-8 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-sm flex flex-col items-center">
            <Award className="w-10 h-10 text-[#38BDF8] mb-4" />
            <p className="font-heading text-5xl font-extrabold text-[#38BDF8] mb-2">4.3x</p>
            <p className="text-[15px] font-medium text-slate-400">Higher Profit Growth Odds</p>
          </div>
        </div>
      </main>

      {/* Bottom Executive Bar */}
      <footer className="relative z-10 flex items-center justify-between px-12 py-3 border-t border-white/10 bg-[#071426]/80 text-[11px] text-slate-400">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 text-slate-300">
            <ShieldCheck className="w-3.5 h-3.5 text-[#10B981]" />
            Prepared for Fortune 500 Leadership, Board Directors &amp; Institutional Investors
          </span>
        </div>
        <div className="font-mono font-semibold text-cyan-300 tracking-widest">
          {String(number).padStart(2, '0')} / {String(total).padStart(2, '0')}
        </div>
      </footer>
    </div>
  );
}