import React from 'react';
import { TrendingUp, DollarSign, Award } from 'lucide-react';
import SlideChrome from '../components/SlideChrome';

export default function Slide09PredictiveROI() {
  return (
    <SlideChrome
      variant="light"
      sectionLabel="PREDICTIVE ANALYTICS · DIGITAL CAPACITY & ROI"
      activeStep={8}
      sourceNote="30-AE Pilot · $120K ACV · Gartner Digital Capacity (dCU) Model"
    >
      {/* Clean Header */}
      <div className="mb-5">
        <h2 className="font-heading text-[30px] font-extrabold tracking-tight text-[#0B1F3A] leading-tight">
          Predictive Impact &amp; Pilot ROI
        </h2>
        <p className="text-[15px] text-[#1F2937] mt-1.5 border-l-[3px] border-[#10B981] pl-3">
          Just <span className="font-semibold text-[#0B1F3A]">+0.4 extra deals per rep</span> turns
          a $9,850 pilot into <span className="font-semibold text-[#10B981]">+$1.44M new ARR</span>.
        </p>
      </div>

      {/* 3 Spacious Headline KPIs */}
      <div
        data-motion="rise"
        data-motion-order="1"
        className="grid grid-cols-3 gap-5 mb-5"
      >
        <div className="bg-white rounded-2xl border border-slate-200 px-6 py-5 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Pilot Win-Rate Lift
            </p>
            <p className="font-heading text-3xl font-extrabold text-[#0B1F3A] mt-1">
              18.2% → 22.5%
            </p>
            <p className="text-xs text-[#10B981] font-semibold mt-1">
              +12 closed deals across 30 reps
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 flex items-center justify-center shrink-0">
            <TrendingUp className="w-6 h-6 text-[#10B981]" />
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 px-6 py-5 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              12-Month Pilot Gain
            </p>
            <p className="font-heading text-3xl font-extrabold text-[#2563EB] mt-1">+$1.44M</p>
            <p className="text-xs text-slate-600 font-medium mt-1">
              12 deals × $120K average deal
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center shrink-0">
            <DollarSign className="w-6 h-6 text-[#2563EB]" />
          </div>
        </div>

        <div className="bg-[#0B1F3A] text-white rounded-2xl px-6 py-5 shadow-md flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-cyan-300">
              Pilot Payback Speed
            </p>
            <p className="font-heading text-3xl font-extrabold text-[#10B981] mt-1">&lt; 1 Deal</p>
            <p className="text-xs text-slate-300 font-medium mt-1">
              1 closed deal returns 12x budget
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center shrink-0">
            <Award className="w-6 h-6 text-amber-300" />
          </div>
        </div>
      </div>

      {/* 2 Clean, High-Impact Visual Cards */}
      <div
        data-motion="rise"
        data-motion-order="2"
        className="flex-1 grid grid-cols-12 gap-5 items-stretch overflow-hidden"
      >
        {/* Left 6 Cols: Cost vs. Return Bars */}
        <div className="col-span-6 bg-[#0B1F3A] text-white rounded-2xl p-6 shadow-md flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <h3 className="font-heading text-base font-bold text-white">
              Cost vs. 12-Month Return
            </h3>
            <span className="px-3 py-1 rounded-full bg-[#10B981]/20 border border-[#10B981]/40 font-mono text-xs text-[#10B981] font-bold">
              146x PILOT ROI
            </span>
          </div>

          <div className="space-y-5 my-2">
            <div>
              <div className="flex justify-between text-sm mb-1.5">
                <span className="text-slate-300">Pilot Budget</span>
                <span className="font-mono font-bold text-amber-300">$9.85K</span>
              </div>
              <div className="h-3.5 bg-white/10 rounded-full">
                <div className="w-[4%] h-full bg-amber-400 rounded-full" />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-sm mb-1.5">
                <span className="text-slate-200">Just 1 Extra Closed Deal</span>
                <span className="font-mono font-bold text-cyan-300">$120K (12x Cost)</span>
              </div>
              <div className="h-3.5 bg-white/10 rounded-full">
                <div className="w-[22%] h-full bg-[#06B6D4] rounded-full" />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-sm mb-1.5">
                <span className="text-white font-semibold">12-Month Pilot Gain (12 Deals)</span>
                <span className="font-mono text-base font-extrabold text-[#10B981]">$1.44M</span>
              </div>
              <div className="h-4 bg-white/10 rounded-full">
                <div className="w-full h-full bg-gradient-to-r from-[#06B6D4] to-[#10B981] rounded-full" />
              </div>
            </div>
          </div>

          <p className="text-xs text-slate-300 pt-3 border-t border-white/10">
            Also cuts rep turnover by <strong className="text-white">25%</strong>—avoiding{' '}
            <strong className="text-[#10B981]">$360K</strong> in rehiring costs.
          </p>
        </div>

        {/* Right 6 Cols: Extra Selling Power Without Hiring */}
        <div className="col-span-6 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <h3 className="font-heading text-base font-bold text-[#0B1F3A]">
              Extra Selling Power (Zero New Headcount)
            </h3>
            <span className="px-3 py-1 rounded-full bg-blue-50 font-mono text-xs text-[#2563EB] font-bold">
              GARTNER dCU
            </span>
          </div>

          {/* Big Equation */}
          <div className="grid grid-cols-3 gap-3 items-center text-center my-2">
            <div className="bg-slate-50 rounded-2xl py-5 px-3 border border-slate-200">
              <p className="font-heading text-4xl font-extrabold text-[#0B1F3A]">30</p>
              <p className="text-xs font-medium text-slate-500 mt-1">Pilot Reps</p>
            </div>

            <div className="bg-blue-50/70 rounded-2xl py-5 px-3 border border-blue-200">
              <p className="font-heading text-4xl font-extrabold text-[#2563EB]">+ 9</p>
              <p className="text-xs font-semibold text-[#2563EB] mt-1">AI Capacity (dCU)</p>
            </div>

            <div className="bg-emerald-50 rounded-2xl py-5 px-3 border-2 border-[#10B981]">
              <p className="font-heading text-4xl font-extrabold text-[#10B981]">= 39</p>
              <p className="text-xs font-bold text-emerald-800 mt-1">Effective Sellers</p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <div>
              <p className="text-xs font-mono uppercase font-bold text-[#2563EB]">
                FULL 300-REP ENTERPRISE SCALE
              </p>
              <p className="text-sm font-semibold text-[#0B1F3A] mt-0.5">
                +90 Virtual Sellers &amp; +$10.8M Annual Revenue
              </p>
            </div>
            <span className="font-heading text-xl font-extrabold text-[#10B981]">+$10.8M</span>
          </div>
        </div>
      </div>
    </SlideChrome>
  );
}