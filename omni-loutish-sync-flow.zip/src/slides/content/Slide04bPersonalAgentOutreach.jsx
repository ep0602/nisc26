import React from 'react';
import {
  Linkedin,
  Database,
  Globe,
  Building2,
  Bot,
  Mail,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  UserCheck,
  Send,
} from 'lucide-react';
import SlideChrome from '../components/SlideChrome';

export default function Slide04bPersonalAgentOutreach() {
  return (
    <SlideChrome
      variant="light"
      sectionLabel="AUTONOMOUS OUTREACH · PERSONAL AI AGENT & PUBLIC INTEL"
      sourceNote="Public Web & LinkedIn Enrichment · Gartner Authentic Voice Matching (Solves 73% AI Spam Rejection)"
    >
      {/* Header */}
      <div className="mb-3.5">
        <h2 className="font-heading text-[27px] font-extrabold tracking-tight text-[#0B1F3A] leading-tight">
          Personal Employee AI Agent &amp; Public Data Outreach
        </h2>
        <p className="text-[13.5px] text-[#1F2937] mt-1 border-l-[3px] border-[#2563EB] pl-3">
          Every employee gets a dedicated AI agent that integrates with{' '}
          <span className="font-semibold text-[#0B1F3A]">
            LinkedIn, ZoomInfo &amp; public buyer data
          </span>{' '}
          to send authentic, 1-to-1 personalized emails.
        </p>
      </div>

      {/* 3-Column Visual Pipeline: Public Data -> Employee AI Agent -> Personalized Email */}
      <div className="flex-1 grid grid-cols-12 gap-4 items-stretch overflow-hidden">
        {/* Col 1-4: Public Data Sources + ZoomInfo */}
        <div
          data-motion="rise"
          data-motion-order="1"
          className="col-span-4 relative bg-white rounded-2xl border border-slate-200 shadow-sm p-4 flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <span className="font-mono text-[10px] font-bold uppercase tracking-wider text-[#2563EB]">
                1. PUBLIC DATA &amp; ZOOMINFO SYNC
              </span>
              <span className="px-2 py-0.5 rounded-full bg-blue-50 text-[#2563EB] font-mono text-[9.5px] font-bold">
                AUTO-SYNC
              </span>
            </div>

            <div className="space-y-2 mt-2.5">
              {/* LinkedIn Card */}
              <div className="p-2.5 rounded-xl bg-blue-50/60 border border-blue-200/80">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-[#2563EB] text-white flex items-center justify-center shrink-0">
                    <Linkedin className="w-3.5 h-3.5" />
                  </div>
                  <h3 className="font-heading text-xs font-extrabold text-[#0B1F3A]">
                    LinkedIn Profile &amp; Activity
                  </h3>
                </div>
                <p className="text-[11px] text-slate-700 mt-1 leading-snug">
                  Recent posts, job changes, career history &amp; warm mutual connections.
                </p>
              </div>

              {/* ZoomInfo Integration Card */}
              <div className="p-2.5 rounded-xl bg-indigo-50/70 border border-indigo-200/90">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0">
                      <Database className="w-3.5 h-3.5" />
                    </div>
                    <h3 className="font-heading text-xs font-extrabold text-[#0B1F3A]">
                      ZoomInfo Integration
                    </h3>
                  </div>
                  <span className="px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-700 font-mono text-[9px] font-bold">
                    B2B INTENT
                  </span>
                </div>
                <p className="text-[11px] text-slate-700 mt-1 leading-snug">
                  Verified contacts, live org charts, buyer intent spikes &amp; firmographics.
                </p>
              </div>

              {/* Company News & Web */}
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-cyan-50 border border-cyan-200 text-[#06B6D4] flex items-center justify-center shrink-0">
                    <Globe className="w-3.5 h-3.5" />
                  </div>
                  <h3 className="font-heading text-xs font-extrabold text-[#0B1F3A]">
                    Public Web, News &amp; PR
                  </h3>
                </div>
                <p className="text-[11px] text-slate-700 mt-1 leading-snug">
                  Funding rounds, product launches, podcasts &amp; executive interviews.
                </p>
              </div>

              {/* Filings & Hiring */}
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-emerald-50 border border-emerald-200 text-[#10B981] flex items-center justify-center shrink-0">
                    <Building2 className="w-3.5 h-3.5" />
                  </div>
                  <h3 className="font-heading text-xs font-extrabold text-[#0B1F3A]">
                    Filings &amp; Hiring Signals
                  </h3>
                </div>
                <p className="text-[11px] text-slate-700 mt-1 leading-snug">
                  10-K/earnings priorities, open hiring surges &amp; tech-stack clues.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-600">
            <span className="font-semibold text-[#0B1F3A]">ZoomInfo + Compliant OSINT</span>
            <span className="font-mono text-[10px] text-[#10B981] font-bold">0 MIN MANUAL PREP</span>
          </div>

          <div className="flex absolute -right-3 top-1/2 -translate-y-1/2 z-20 w-6 h-6 rounded-full bg-[#2563EB] text-white items-center justify-center shadow-md">
            <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Col 5-8: Dedicated Employee AI Agent */}
        <div
          data-motion="rise"
          data-motion-order="2"
          className="col-span-4 relative bg-[#0B1F3A] text-white rounded-2xl shadow-md p-4 flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between pb-2.5 border-b border-white/10">
              <span className="font-mono text-[10px] font-bold uppercase tracking-wider text-cyan-300">
                2. EMPLOYEE&apos;S PERSONAL AGENT
              </span>
              <span className="px-2 py-0.5 rounded-full bg-cyan-400/15 border border-cyan-300/30 text-cyan-200 font-mono text-[9.5px] font-bold">
                1 PER REP
              </span>
            </div>

            {/* Central Agent Identity */}
            <div className="mt-3 p-3 rounded-xl bg-gradient-to-r from-[#2563EB]/30 to-[#06B6D4]/20 border border-cyan-400/30 flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-[#06B6D4]/25 border border-cyan-300/40 flex items-center justify-center shrink-0">
                <Bot className="w-6 h-6 text-cyan-300" />
              </div>
              <div>
                <h3 className="font-heading text-sm font-extrabold text-white">
                  Rep-Matched Outreach Twin
                </h3>
                <p className="text-[11px] text-cyan-200 leading-snug">
                  Trained on each employee&apos;s authentic tone + top-rep messaging DNA.
                </p>
              </div>
            </div>

            {/* 3 Core Agent Actions */}
            <div className="space-y-2.5 mt-3">
              <div className="p-2.5 rounded-xl bg-white/[0.06] border border-white/10 flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-cyan-300 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-white">Connects Signal to Pain Point</h4>
                  <p className="text-[11px] text-slate-300 leading-snug">
                    Links a buyer&apos;s LinkedIn post or company initiative directly to deal value.
                  </p>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-white/[0.06] border border-white/10 flex items-start gap-2.5">
                <UserCheck className="w-4 h-4 text-[#10B981] shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-white">Adapts to Buyer Decision Style</h4>
                  <p className="text-[11px] text-slate-300 leading-snug">
                    Writes crisp bullets for Directive VPs or ROI proof for Analytical CFOs.
                  </p>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-white/[0.06] border border-white/10 flex items-start gap-2.5">
                <Send className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-white">Sends Personalized Sequences</h4>
                  <p className="text-[11px] text-slate-300 leading-snug">
                    Dispatches 1-to-1 emails &amp; follow-ups at peak buyer open windows.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#10B981]/15 border border-[#10B981]/40 text-[11px] text-slate-200 leading-snug">
            <strong className="text-[#10B981]">Fixes the AI Paradox:</strong> Turns saved admin hours
            into research-backed outreach instead of generic blasts.
          </div>

          <div className="flex absolute -right-3 top-1/2 -translate-y-1/2 z-20 w-6 h-6 rounded-full bg-[#10B981] text-white items-center justify-center shadow-md">
            <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Col 9-12: Live Personalized Email Output */}
        <div
          data-motion="rise"
          data-motion-order="3"
          className="col-span-4 bg-white rounded-2xl border-2 border-[#10B981]/60 shadow-sm p-4 flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between pb-2.5 border-b border-slate-100">
              <div className="flex items-center gap-1.5">
                <Mail className="w-4 h-4 text-[#10B981]" />
                <span className="font-mono text-[10px] font-bold uppercase tracking-wider text-emerald-700">
                  3. 1:1 PERSONALIZED EMAIL SENT
                </span>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-mono text-[9.5px] font-bold">
                98% VOICE MATCH
              </span>
            </div>

            {/* Simulated Email Envelope */}
            <div className="mt-2.5 rounded-xl bg-slate-50 border border-slate-200 p-3 space-y-2">
              <div className="text-[10.5px] text-slate-500 border-b border-slate-200 pb-1.5 space-y-0.5">
                <p>
                  <strong className="text-[#0B1F3A]">To:</strong> Elena Rostova, VP Sales · FinCore
                </p>
                <p>
                  <strong className="text-[#0B1F3A]">Subject:</strong> Your LinkedIn post on Q3 AE
                  ramp + Austin hiring
                </p>
              </div>

              <div className="space-y-2 text-[11.5px] text-slate-700 leading-snug">
                <div className="p-2 rounded-lg bg-blue-50/80 border-l-2 border-[#2563EB]">
                  <span className="font-mono text-[9.5px] font-bold text-[#2563EB] uppercase block">
                    LinkedIn Hook
                  </span>
                  &ldquo;Saw your post Tuesday on onboarding 20 new AEs in Austin—loved your point on
                  protecting deal quality.&rdquo;
                </div>

                <div className="p-2 rounded-lg bg-cyan-50/80 border-l-2 border-[#06B6D4]">
                  <span className="font-mono text-[9.5px] font-bold text-cyan-800 uppercase block">
                    Public Q3 Filing Tie-In
                  </span>
                  &ldquo;With FinCore&apos;s enterprise push this quarter, peers use roleplay coaching
                  to cut new-hire ramp by 28%.&rdquo;
                </div>

                <div className="p-2 rounded-lg bg-emerald-50/80 border-l-2 border-[#10B981]">
                  <span className="font-mono text-[9.5px] font-bold text-emerald-800 uppercase block">
                    Rep&apos;s Authentic CTA
                  </span>
                  &ldquo;Open to a 10-min walkthrough Thursday, Elena? — Marcus&rdquo;
                </div>
              </div>
            </div>
          </div>

          {/* Impact Footer */}
          <div className="pt-2.5 border-t border-slate-100 space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-1.5 font-semibold text-[#0B1F3A]">
                <CheckCircle2 className="w-4 h-4 text-[#10B981]" /> Zero Generic Templates
              </span>
              <span className="font-mono text-[10.5px] font-bold text-[#10B981]">
                BEATS 73% SPAM BLOCK
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              Every outreach reflects real buyer news and the employee&apos;s natural voice.
            </p>
          </div>
        </div>
      </div>
    </SlideChrome>
  );
}