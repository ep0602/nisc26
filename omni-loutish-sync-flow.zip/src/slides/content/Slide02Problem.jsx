import React from 'react';
import { AlertTriangle, TrendingDown, Users, MailWarning, UserX } from 'lucide-react';
import SlideChrome from '../components/SlideChrome';

export default function Slide02Problem() {
  return (
    <SlideChrome
      variant="light"
      sectionLabel="DIAGNOSTIC · COMMERCIAL PARADOX"
      activeStep={1}
      sourceNote="Sources: ACS 6-Mo Telemetry · Gartner Sales Productivity Survey (n=210 CSOs)"
    >
      {/* A & B Message Hierarchy */}
      <div className="mb-3">
        <h2 className="font-heading text-[26px] font-extrabold tracking-tight text-[#0B1F3A] leading-tight">
          The Workforce &amp; Sales Performance Problem
        </h2>
        <p className="text-[13.5px] text-[#1F2937] mt-1 border-l-[3px] border-[#2563EB] pl-3">
          78% AI adoption drove <span className="font-semibold text-[#0B1F3A]">+35% more activity</span>{' '}
          but <span className="font-semibold text-rose-600">flat revenue</span> (18.2% win rate) and 73%
          buyer pushback.
        </p>
      </div>

      {/* 68% Visual Workspace */}
      <div className="flex-1 grid grid-cols-12 gap-5 items-stretch overflow-hidden">
        {/* Left 7 Cols: Side-by-Side Column Chart — Busywork Up vs. Sales Flat */}
        <div
          data-motion="rise"
          data-motion-order="1"
          className="col-span-7 bg-white rounded-xl border border-slate-200 shadow-sm p-4 flex flex-col justify-between"
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
            <div>
              <h3 className="font-heading text-sm font-bold text-[#0B1F3A]">
                6 Months After AI Rollout: Busywork Surged, Sales Stayed Flat
              </h3>
              <p className="text-[11px] text-slate-500">
                300 Sales Reps · $120K Avg. Deal Size
              </p>
            </div>
            <span className="px-2.5 py-1 rounded bg-rose-50 border border-rose-200 font-mono text-[10px] font-semibold text-rose-700">
              THE AI PARADOX
            </span>
          </div>

          {/* Visual 2-Group Vertical Bar Comparison */}
          <div className="flex-1 grid grid-cols-2 gap-4 my-3 items-stretch">
            {/* Left Group: Activity Exploded */}
            <div className="rounded-xl bg-blue-50/50 border border-blue-100 p-3 flex flex-col justify-between">
              <div className="text-center">
                <span className="px-2.5 py-0.5 rounded-full bg-[#2563EB] text-white font-mono text-[10px] font-bold uppercase">
                  AI Activity Exploded
                </span>
              </div>

              <div className="flex items-end justify-around h-44 pt-6 pb-2 border-b border-blue-200/70">
                <div className="flex flex-col items-center gap-1.5 w-16">
                  <span className="font-heading text-base font-extrabold text-[#2563EB]">78%</span>
                  <div className="w-11 h-28 rounded-t-lg bg-gradient-to-t from-[#2563EB] to-[#38BDF8] shadow-sm" />
                </div>
                <div className="flex flex-col items-center gap-1.5 w-16">
                  <span className="font-heading text-base font-extrabold text-[#06B6D4]">72%</span>
                  <div className="w-11 h-24 rounded-t-lg bg-gradient-to-t from-[#06B6D4] to-cyan-300 shadow-sm" />
                </div>
                <div className="flex flex-col items-center gap-1.5 w-16">
                  <span className="font-heading text-base font-extrabold text-[#F59E0B]">+35%</span>
                  <div className="w-11 h-16 rounded-t-lg bg-gradient-to-t from-[#F59E0B] to-amber-300 shadow-sm" />
                </div>
              </div>

              <div className="grid grid-cols-3 text-center text-[10.5px] font-semibold text-slate-700 pt-1">
                <span>Reps Using AI</span>
                <span>Saved Time Wasted</span>
                <span>Cold Emails Sent</span>
              </div>
            </div>

            {/* Right Group: Revenue Stalled */}
            <div className="rounded-xl bg-rose-50/50 border border-rose-100 p-3 flex flex-col justify-between">
              <div className="text-center">
                <span className="px-2.5 py-0.5 rounded-full bg-rose-600 text-white font-mono text-[10px] font-bold uppercase">
                  Sales Results Stalled
                </span>
              </div>

              <div className="flex items-end justify-around h-44 pt-6 pb-2 border-b border-rose-200/70">
                <div className="flex flex-col items-center gap-1.5 w-16">
                  <span className="font-heading text-base font-extrabold text-slate-700">+4%</span>
                  <div className="w-11 h-4 rounded-t-md bg-slate-400" />
                </div>
                <div className="flex flex-col items-center gap-1.5 w-16">
                  <span className="font-heading text-base font-extrabold text-rose-600">-0.3%</span>
                  <div className="w-11 h-2.5 rounded-t-md bg-rose-500" />
                </div>
                <div className="flex flex-col items-center gap-1.5 w-16">
                  <span className="font-heading text-base font-extrabold text-slate-500">0%</span>
                  <div className="w-11 h-1.5 rounded-t-md bg-slate-300" />
                </div>
              </div>

              <div className="grid grid-cols-3 text-center text-[10.5px] font-semibold text-slate-700 pt-1">
                <span>New Pipeline</span>
                <span>Win Rate (18.2%)</span>
                <span>Deal Size ($120K)</span>
              </div>
            </div>
          </div>

          {/* Bottom Gartner Budget Ceiling Strip */}
          <div className="flex items-center justify-between bg-[#0B1F3A] text-white px-3.5 py-2 rounded-lg">
            <span className="text-[11.5px] font-medium">
              Why? Companies spend <strong className="text-amber-300">85%</strong> of budget on payroll
              vs. just <strong className="text-cyan-300">1%</strong> on coaching
            </span>
            <span className="font-mono text-[10px] text-cyan-300">GARTNER</span>
          </div>
        </div>

        {/* Right 5 Cols: 4 Root-Cause Diagnostic Cards */}
        <div
          data-motion="rise"
          data-motion-order="2"
          className="col-span-5 flex flex-col justify-between gap-2.5"
        >
          <div className="p-3.5 bg-white rounded-xl border-l-4 border-l-[#F59E0B] border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between">
              <h4 className="font-heading text-xs font-bold text-[#0B1F3A] uppercase tracking-wide">
                1. One-Size-Fits-All Training
              </h4>
              <UserX className="w-4 h-4 text-[#F59E0B]" />
            </div>
            <p className="text-xs text-slate-600 mt-1.5 leading-snug">
              Ignores individual personality &amp; decision styles—causing slow ramp and high churn.
            </p>
          </div>

          <div className="p-3.5 bg-white rounded-xl border-l-4 border-l-[#2563EB] border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between">
              <h4 className="font-heading text-xs font-bold text-[#0B1F3A] uppercase tracking-wide">
                2. Top-10% Behavior Gap
              </h4>
              <TrendingDown className="w-4 h-4 text-[#2563EB]" />
            </div>
            <p className="text-xs text-slate-600 mt-1.5 leading-snug">
              Top AEs map stakeholders &amp; rehearse; <strong className="text-[#0B1F3A]">72%</strong>{' '}
              dump saved hours into cold email blasts.
            </p>
          </div>

          <div className="p-3.5 bg-white rounded-xl border-l-4 border-l-rose-500 border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between">
              <h4 className="font-heading text-xs font-bold text-[#0B1F3A] uppercase tracking-wide">
                3. 73% Buyer Rejection
              </h4>
              <MailWarning className="w-4 h-4 text-rose-500" />
            </div>
            <p className="text-xs text-slate-600 mt-1.5 leading-snug">
              Enterprise buyers block robotic AI spam—triggering formal account escalations.
            </p>
          </div>

          <div className="p-3.5 bg-white rounded-xl border-l-4 border-l-[#06B6D4] border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between">
              <h4 className="font-heading text-xs font-bold text-[#0B1F3A] uppercase tracking-wide">
                4. 82% Manager Blindspot
              </h4>
              <Users className="w-4 h-4 text-[#06B6D4]" />
            </div>
            <p className="text-xs text-slate-600 mt-1.5 leading-snug">
              Managers still audit call/email counts instead of coaching deal strategy in 1:1s.
            </p>
          </div>
        </div>
      </div>
    </SlideChrome>
  );
}