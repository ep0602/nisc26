import React from 'react';
import { DollarSign, Calendar, Rocket, ShieldCheck, UserCheck, Layers } from 'lucide-react';
import SlideChrome from '../components/SlideChrome';

export default function Slide10BudgetRoadmap() {
  return (
    <SlideChrome
      variant="dark"
      sectionLabel="PILOT BUDGET (<$10K) · ROADMAP & VISION"
      activeStep={9}
      sourceNote="$9,850 Turnkey 90-Day Pilot ($150 Under $10K Cap) · Owned by RevOps Data Architect"
    >
      {/* A & B Message Hierarchy */}
      <div className="mb-3">
        <h2 className="font-heading text-[26px] font-extrabold tracking-tight text-white leading-tight">
          $9,850 Pilot, 90-Day Roadmap &amp; Vision
        </h2>
        <p className="text-[13.5px] text-slate-200 mt-1 border-l-[3px] border-[#10B981] pl-3">
          Deploys <span className="text-[#10B981] font-semibold">under $10K in 90 days</span>—proving
          revenue lift before scaling into an enterprise Workforce OS.
        </p>
      </div>

      {/* 70% Visual Workspace */}
      <div className="flex-1 grid grid-cols-12 gap-5 items-stretch overflow-hidden">
        {/* Left 5 Cols: Visual Donut + Clean 5-Category Budget Bars */}
        <div className="col-span-5 rounded-xl bg-white/[0.05] border border-white/15 p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-[#10B981]" />
              <h3 className="font-heading text-sm font-bold text-white">
                90-Day Pilot Budget (&lt;$10K Cap)
              </h3>
            </div>
            <span className="px-2.5 py-0.5 rounded bg-[#10B981]/20 border border-[#10B981]/50 font-mono text-xs font-bold text-[#10B981]">
              $9,850
            </span>
          </div>

          {/* Visual SVG Donut Ring + Summary */}
          <div className="flex items-center gap-4 my-2">
            <svg viewBox="0 0 100 100" className="w-24 h-24 shrink-0 -rotate-90">
              <circle cx="50" cy="50" r="38" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="14" />
              {/* 26.4% AI Models (63 / 239) */}
              <circle cx="50" cy="50" r="38" fill="none" stroke="#2563EB" strokeWidth="14" strokeDasharray="63 239" strokeDashoffset="0" />
              {/* 24.4% Setup (58 / 239) */}
              <circle cx="50" cy="50" r="38" fill="none" stroke="#06B6D4" strokeWidth="14" strokeDasharray="58 239" strokeDashoffset="-63" />
              {/* 23.9% Cloud + Analytics (57 / 239) */}
              <circle cx="50" cy="50" r="38" fill="none" stroke="#10B981" strokeWidth="14" strokeDasharray="57 239" strokeDashoffset="-121" />
              {/* 10.1% Rep Rewards (24 / 239) */}
              <circle cx="50" cy="50" r="38" fill="none" stroke="#F59E0B" strokeWidth="14" strokeDasharray="24 239" strokeDashoffset="-178" />
              {/* 15.2% QA + Buffer (37 / 239) */}
              <circle cx="50" cy="50" r="38" fill="none" stroke="#94A3B8" strokeWidth="14" strokeDasharray="37 239" strokeDashoffset="-202" />
            </svg>
            <div>
              <p className="font-heading text-2xl font-extrabold text-white">$9,850</p>
              <p className="text-xs text-[#10B981] font-semibold">$150 Under $10,000 Limit</p>
              <p className="text-[11px] text-slate-300 mt-1">
                Zero new headcount; plugs into existing CRM.
              </p>
            </div>
          </div>

          {/* 5 Clean Visual Bar Categories */}
          <div className="space-y-2 text-xs">
            <div>
              <div className="flex justify-between mb-0.5">
                <span className="text-slate-200">AI Models &amp; Router Credits</span>
                <span className="font-mono font-bold text-white">$2,600 (26%)</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full">
                <div className="w-[82%] h-full bg-[#2563EB] rounded-full" />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-0.5">
                <span className="text-slate-200">CRM Setup &amp; Integration</span>
                <span className="font-mono font-bold text-white">$2,400 (24%)</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full">
                <div className="w-[76%] h-full bg-[#06B6D4] rounded-full" />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-0.5">
                <span className="text-slate-200">Cloud &amp; Analytics ($1.2K + $1.15K)</span>
                <span className="font-mono font-bold text-white">$2,350 (24%)</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full">
                <div className="w-[74%] h-full bg-[#10B981] rounded-full" />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-0.5">
                <span className="text-slate-200">Testing &amp; Contingency ($800 + $700)</span>
                <span className="font-mono font-bold text-white">$1,500 (15%)</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full">
                <div className="w-[48%] h-full bg-slate-400 rounded-full" />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-0.5">
                <span className="text-slate-200">Rep Rewards &amp; Bonuses</span>
                <span className="font-mono font-bold text-amber-300">$1,000 (10%)</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full">
                <div className="w-[32%] h-full bg-[#F59E0B] rounded-full" />
              </div>
            </div>
          </div>
        </div>

        {/* Right 7 Cols: 90-Day Pilot Roadmap + 3-Horizon Future Vision */}
        <div className="col-span-7 flex flex-col justify-between gap-3">
          {/* Top: 90-Day Pilot Execution Roadmap */}
          <div className="rounded-xl bg-white/[0.05] border border-white/15 p-4">
            <div className="flex items-center justify-between mb-2.5">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#06B6D4]" />
                <h3 className="font-heading text-sm font-bold text-white">
                  90-Day Implementation Roadmap (30-AE Pilot + 5 Managers)
                </h3>
              </div>
              <span className="flex items-center gap-1 font-mono text-[10px] text-cyan-300">
                <UserCheck className="w-3.5 h-3.5" /> Owner: RevOps Data Architect
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2.5">
              <div className="p-3 rounded-lg bg-[#0B1F3A] border-t-2 border-t-[#2563EB] border border-white/10">
                <span className="font-mono text-[10px] text-cyan-300">DAYS 1–30 · STRIP</span>
                <h4 className="font-heading text-xs font-bold text-white mt-0.5">
                  Connect &amp; Baseline
                </h4>
                <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                  Sync CRM + Copilot, deploy Router, profile 30 AEs.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-[#0B1F3A] border-t-2 border-t-[#06B6D4] border border-white/10">
                <span className="font-mono text-[10px] text-cyan-200">DAYS 31–60 · STACK</span>
                <h4 className="font-heading text-xs font-bold text-white mt-0.5">
                  Simulate &amp; Coach
                </h4>
                <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                  Launch 4-Persona Sim, bias alerts &amp; weekly briefs.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-[#0B1F3A] border-t-2 border-t-[#10B981] border border-white/10">
                <span className="font-mono text-[10px] text-[#10B981]">DAYS 61–90 · SHARPEN</span>
                <h4 className="font-heading text-xs font-bold text-white mt-0.5">
                  Audit &amp; Scale
                </h4>
                <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                  Run CSPI 1:1s, verify win lift, unlock 300-AE scale.
                </p>
              </div>
            </div>
          </div>

          {/* Bottom: 3-Horizon Future Vision */}
          <div className="flex-1 rounded-xl bg-gradient-to-r from-[#2563EB]/25 via-[#112A4E] to-[#08172E] border border-cyan-400/40 p-4 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Rocket className="w-4 h-4 text-[#10B981]" />
                <h3 className="font-heading text-sm font-bold text-white">
                  3-Horizon Enterprise Vision
                </h3>
              </div>
              <span className="font-mono text-[10px] text-amber-300 uppercase">
                VENTURE MOAT
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2.5 my-1.5">
              <div className="p-2.5 rounded-lg bg-[#0B1F3A]/85 border border-white/10">
                <span className="font-mono text-[9.5px] text-cyan-300">YEAR 1 · REVENUE</span>
                <p className="text-xs font-bold text-white mt-0.5">300-AE Scale</p>
                <p className="text-[10.5px] text-slate-300 mt-0.5">
                  +90 dCUs &amp; +$10.8M ARR potential.
                </p>
              </div>
              <div className="p-2.5 rounded-lg bg-[#0B1F3A]/85 border border-white/10">
                <span className="font-mono text-[9.5px] text-[#38BDF8]">YEAR 2 · EXPAND</span>
                <p className="text-xs font-bold text-white mt-0.5">Enterprise Coach</p>
                <p className="text-[10.5px] text-slate-300 mt-0.5">
                  CS, Product, Engineering &amp; HR teams.
                </p>
              </div>
              <div className="p-2.5 rounded-lg bg-[#0B1F3A]/85 border border-[#10B981]/40">
                <span className="font-mono text-[9.5px] text-[#10B981]">YEAR 3+ · OS</span>
                <p className="text-xs font-bold text-white mt-0.5">Workforce OS</p>
                <p className="text-[10.5px] text-slate-300 mt-0.5">
                  Autonomous debiasing &amp; talent intelligence.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1.5 border-t border-white/10 text-xs">
              <span className="font-semibold text-white flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#10B981]" />
                Decision Ask: Approve $9,850 90-Day Pilot &amp; Assign RevOps Data Architect
              </span>
              <Layers className="w-4 h-4 text-cyan-300 shrink-0" />
            </div>
          </div>
        </div>
      </div>
    </SlideChrome>
  );
}