import React from 'react';
import { Zap, BarChart2, Lightbulb, HeartHandshake, ArrowRight } from 'lucide-react';
import SlideChrome from '../components/SlideChrome';

export default function Slide04DiscoveryStyles() {
  return (
    <SlideChrome
      variant="light"
      sectionLabel="PERSONALIZATION · BEHAVIORAL INTELLIGENCE"
      activeStep={3}
      sourceNote="Rowe & Boulgarides Managerial Decision Styles · Continuous I-O Telemetry"
    >
      {/* A & B Message Hierarchy */}
      <div className="mb-3">
        <h2 className="font-heading text-[26px] font-extrabold tracking-tight text-[#0B1F3A] leading-tight">
          Buyer Intel, Top-Rep DNA &amp; 4 Coaching Styles
        </h2>
        <p className="text-[13.5px] text-[#1F2937] mt-1 border-l-[3px] border-[#06B6D4] pl-3">
          Combines call recordings &amp; online client data with{' '}
          <span className="font-semibold text-[#0B1F3A]">top-performer traits</span>—reframing
          weaknesses around each rep's strengths.
        </p>
      </div>

      {/* 68% Visual Workspace */}
      <div className="flex-1 grid grid-cols-12 gap-5 items-stretch overflow-hidden">
        {/* Left 5 Cols: Buyer Needs + Top-Rep Foundation */}
        <div
          data-motion="rise"
          data-motion-order="1"
          className="col-span-5 bg-[#0B1F3A] text-white rounded-xl p-4 flex flex-col justify-between shadow-md"
        >
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <h3 className="font-heading text-sm font-bold text-white">
                Client Needs &amp; Top-Rep Skill Map
              </h3>
              <span className="font-mono text-[10px] text-cyan-300">LIVE INTEL</span>
            </div>

            {/* 3 Clear Data Sources */}
            <div className="flex items-center justify-between text-[10px] font-medium mt-2.5 bg-white/[0.06] px-2.5 py-1.5 rounded-lg border border-white/10">
              <span className="text-cyan-200">Call Recordings</span>
              <ArrowRight className="w-3 h-3 text-cyan-400" />
              <span className="text-cyan-200">Online Client Data</span>
              <ArrowRight className="w-3 h-3 text-cyan-400" />
              <span className="text-cyan-200">Top-Rep DNA</span>
            </div>
          </div>

          {/* Clean Visual Skill Bars */}
          <div className="space-y-2.5 my-2">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-200 font-medium">Customer Need Discovery (Calls + Web)</span>
                <span className="font-mono font-bold text-[#10B981]">94%</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <div className="w-[94%] h-full bg-[#10B981] rounded-full" />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-200 font-medium">Active Listening &amp; Empathy</span>
                <span className="font-mono font-bold text-[#38BDF8]">88%</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <div className="w-[88%] h-full bg-[#38BDF8] rounded-full" />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-200 font-medium">Price Defense (Reframed via Strengths)</span>
                <span className="font-mono font-bold text-[#F59E0B]">64% → Coaching</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <div className="w-[64%] h-full bg-[#F59E0B] rounded-full" />
              </div>
            </div>
          </div>

          {/* Positive Sales Traits Foundation Box */}
          <div className="p-2.5 rounded-lg bg-[#10B981]/15 border border-[#10B981]/40 text-[11.5px] leading-snug">
            <span className="font-mono text-[10px] font-bold text-[#10B981] uppercase block mb-0.5">
              TOP-PERFORMER AI FOUNDATION
            </span>
            <span className="text-slate-200">
              Uses top reps' habits to lift struggling sellers—<strong>reframing weaknesses</strong>{' '}
              to complement their natural style.
            </span>
          </div>
        </div>

        {/* Right 7 Cols: 2x2 Decision-Making Style Matrix */}
        <div
          data-motion="rise"
          data-motion-order="2"
          className="col-span-7 flex flex-col justify-between"
        >
          <div className="flex items-center justify-between px-2 mb-1">
            <span className="font-mono text-[10px] font-semibold uppercase tracking-wider text-slate-500">
              AXIS: TASK &amp; RATIONAL LOGIC ◄────────────► PEOPLE &amp; SOCIAL ALIGNMENT
            </span>
            <span className="font-mono text-[10px] font-semibold text-[#2563EB]">
              4 MANAGERIAL STYLES
            </span>
          </div>

          <div className="flex-1 grid grid-cols-2 grid-rows-2 gap-3">
            {/* Quadrant 1: DIRECTIVE */}
            <div className="bg-white rounded-xl border-t-4 border-t-[#2563EB] border border-slate-200 p-3.5 shadow-sm flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-7 h-7 rounded-lg bg-blue-50 flex items-center justify-center">
                    <Zap className="w-4 h-4 text-[#2563EB]" />
                  </span>
                  <div>
                    <h3 className="font-heading text-sm font-extrabold text-[#0B1F3A]">
                      Directive
                    </h3>
                    <p className="text-[10px] font-mono text-slate-400">ACTION &amp; STRUCTURE</p>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded bg-blue-50 text-[#2563EB] font-mono text-[10px] font-bold">
                  FAST PACE
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-1.5">
                <strong className="text-slate-800">Traits:</strong> Decisive, structured, results-first.
              </p>
              <div className="mt-2 p-2 rounded-lg bg-blue-50/70 border border-blue-100 text-xs text-[#0B1F3A]">
                <strong className="text-[#2563EB]">AI Mode:</strong> Crisp action bullets &amp; direct tactical plays.
              </div>
            </div>

            {/* Quadrant 2: ANALYTICAL */}
            <div className="bg-white rounded-xl border-t-4 border-t-[#06B6D4] border border-slate-200 p-3.5 shadow-sm flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-7 h-7 rounded-lg bg-cyan-50 flex items-center justify-center">
                    <BarChart2 className="w-4 h-4 text-[#06B6D4]" />
                  </span>
                  <div>
                    <h3 className="font-heading text-sm font-extrabold text-[#0B1F3A]">
                      Analytical
                    </h3>
                    <p className="text-[10px] font-mono text-slate-400">DATA &amp; PRECISION</p>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded bg-cyan-50 text-cyan-700 font-mono text-[10px] font-bold">
                  EVIDENCE LED
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-1.5">
                <strong className="text-slate-800">Traits:</strong> Logical, detail-driven, risk-aware.
              </p>
              <div className="mt-2 p-2 rounded-lg bg-cyan-50/70 border border-cyan-100 text-xs text-[#0B1F3A]">
                <strong className="text-cyan-700">AI Mode:</strong> Deep benchmarks, data &amp; win probabilities.
              </div>
            </div>

            {/* Quadrant 3: CONCEPTUAL */}
            <div className="bg-white rounded-xl border-t-4 border-t-[#F59E0B] border border-slate-200 p-3.5 shadow-sm flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-7 h-7 rounded-lg bg-amber-50 flex items-center justify-center">
                    <Lightbulb className="w-4 h-4 text-[#F59E0B]" />
                  </span>
                  <div>
                    <h3 className="font-heading text-sm font-extrabold text-[#0B1F3A]">
                      Conceptual
                    </h3>
                    <p className="text-[10px] font-mono text-slate-400">VISION &amp; INNOVATION</p>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded bg-amber-50 text-amber-700 font-mono text-[10px] font-bold">
                  BIG PICTURE
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-1.5">
                <strong className="text-slate-800">Traits:</strong> Creative, strategic, future-focused.
              </p>
              <div className="mt-2 p-2 rounded-lg bg-amber-50/70 border border-amber-100 text-xs text-[#0B1F3A]">
                <strong className="text-amber-700">AI Mode:</strong> Scenario planning &amp; strategic account thesis.
              </div>
            </div>

            {/* Quadrant 4: BEHAVIORAL */}
            <div className="bg-white rounded-xl border-t-4 border-t-[#10B981] border border-slate-200 p-3.5 shadow-sm flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-7 h-7 rounded-lg bg-emerald-50 flex items-center justify-center">
                    <HeartHandshake className="w-4 h-4 text-[#10B981]" />
                  </span>
                  <div>
                    <h3 className="font-heading text-sm font-extrabold text-[#0B1F3A]">
                      Behavioral
                    </h3>
                    <p className="text-[10px] font-mono text-slate-400">EMPATHY &amp; CONSENSUS</p>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 font-mono text-[10px] font-bold">
                  COLLABORATIVE
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-1.5">
                <strong className="text-slate-800">Traits:</strong> Empathetic, relational, team-first.
              </p>
              <div className="mt-2 p-2 rounded-lg bg-emerald-50/70 border border-emerald-100 text-xs text-[#0B1F3A]">
                <strong className="text-emerald-700">AI Mode:</strong> Buyer consensus tactics &amp; supportive coaching.
              </div>
            </div>
          </div>
        </div>
      </div>
    </SlideChrome>
  );
}