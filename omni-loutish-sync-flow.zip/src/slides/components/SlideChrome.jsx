import React from 'react';
import { useSlidePosition } from '@/slides/engine/SlidePositionContext';

const STORY_STEPS = [
  'Vision',
  'Problem',
  'Process',
  'Platform',
  'Outreach',
  'Personas',
  'Learning',
  'Simulation',
  'Engagement',
  'ROI',
  'Router',
  'Roadmap',
];

export default function SlideChrome({
  variant = 'light',
  sectionLabel = 'EXECUTIVE BRIEFING',
  activeStep,
  sourceNote = 'Sources: Gartner Sales Productivity Survey (2026) · Aetheris Cloud Systems Diagnostic Telemetry',
  children,
}) {
  const { number, total } = useSlidePosition();
  const resolvedStep = number > 0 ? number - 1 : (activeStep ?? 0);
  const isDark = variant === 'dark';

  return (
    <div
      className={`relative w-[1280px] h-[720px] overflow-hidden select-none flex flex-col justify-between font-body ${
        isDark ? 'bg-[#0B1F3A] text-white' : 'bg-[#F8FAFC] text-[#0B1F3A]'
      }`}
    >
      {/* Ambient architectural background accents */}
      {isDark ? (
        <>
          <div
            className="pointer-events-none absolute -top-32 -right-24 w-[520px] h-[520px] rounded-full opacity-20"
            style={{
              background: 'radial-gradient(circle, #2563EB 0%, rgba(6,182,212,0.18) 45%, transparent 72%)',
            }}
          />
          <div
            className="pointer-events-none absolute -bottom-40 -left-24 w-[480px] h-[480px] rounded-full opacity-15"
            style={{
              background: 'radial-gradient(circle, #06B6D4 0%, transparent 70%)',
            }}
          />
          <div
            className="pointer-events-none absolute inset-0 opacity-[0.04]"
            style={{
              backgroundImage:
                'linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)',
              backgroundSize: '40px 40px',
            }}
          />
        </>
      ) : (
        <>
          <div className="pointer-events-none absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#0B1F3A] via-[#2563EB] to-[#06B6D4]" />
          <div
            className="pointer-events-none absolute -top-36 -right-24 w-[420px] h-[420px] rounded-full opacity-[0.07]"
            style={{
              background: 'radial-gradient(circle, #2563EB 0%, transparent 70%)',
            }}
          />
        </>
      )}

      {/* Top Executive Ribbon */}
      <header
        className={`relative z-10 flex items-center justify-between px-10 pt-4 pb-2.5 border-b ${
          isDark ? 'border-white/10' : 'border-slate-200/90 bg-white/80 backdrop-blur-sm'
        }`}
      >
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="inline-block w-2.5 h-2.5 rounded-sm bg-[#2563EB]" />
            <span className="inline-block w-2.5 h-2.5 rounded-sm bg-[#06B6D4]" />
          </div>
          <span
            className={`font-mono text-[11px] font-semibold tracking-[0.18em] uppercase ${
              isDark ? 'text-cyan-300' : 'text-[#2563EB]'
            }`}
          >
            {sectionLabel}
          </span>
        </div>

        {/* Cohesive Story Arc Tracker */}
        <div className="flex items-center gap-1">
          {STORY_STEPS.map((step, idx) => {
            const isActive = idx === resolvedStep;
            const isPast = idx < resolvedStep;
            return (
              <div key={step} className="flex items-center gap-0.5">
                <span
                  className={`px-1.5 py-0.5 rounded text-[9.5px] font-medium tracking-wide ${
                    isActive
                      ? 'bg-[#2563EB] text-white font-semibold shadow-sm'
                      : isPast
                      ? isDark
                        ? 'text-cyan-300/80 bg-white/5'
                        : 'text-[#0B1F3A]/70 bg-slate-100'
                      : isDark
                      ? 'text-slate-400/60'
                      : 'text-slate-400'
                  }`}
                >
                  {step}
                </span>
              </div>
            );
          })}
        </div>
      </header>

      {/* Main Slide Canvas */}
      <main className="relative z-10 flex-1 px-10 py-4 flex flex-col justify-between overflow-hidden">
        {children}
      </main>

      {/* Executive Footer */}
      <footer
        className={`relative z-10 flex items-center justify-between px-10 py-2 border-t text-[10px] ${
          isDark
            ? 'border-white/10 text-slate-400 bg-[#08172C]/70'
            : 'border-slate-200 text-slate-500 bg-white'
        }`}
      >
        <div className="flex items-center gap-2">
          <span className="font-semibold tracking-wider uppercase text-[#06B6D4]">
            AI WORKFORCE INTELLIGENCE
          </span>
          <span className="opacity-40">|</span>
          <span>{sourceNote}</span>
        </div>
        <div className="font-mono font-semibold tracking-widest">
          {String(number).padStart(2, '0')} / {String(total).padStart(2, '0')}
        </div>
      </footer>
    </div>
  );
}