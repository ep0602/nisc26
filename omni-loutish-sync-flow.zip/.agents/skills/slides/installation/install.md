# Connect the presentation

The installer copies only the slides directory and this skill into the regular app template. It does not replace the template, change dependencies, or edit the router.

1. Import `PresentationPage` in `src/App.jsx`:

```jsx
import PresentationPage from './slides/engine/PresentationPage';
```

2. Inside the existing `Routes`, mount these routes. Replace a conflicting existing root route; keep the existing app providers and authentication setup.

```jsx
<Route path="/" element={<PresentationPage />} />
<Route path="/slides/:id" element={<PresentationPage />} />
<Route path="/present" element={<PresentationPage />} />
<Route path="/present/:id" element={<PresentationPage />} />
<Route path="/speaker" element={<PresentationPage />} />
<Route path="/speaker/:id" element={<PresentationPage />} />
<Route path="/print" element={<PresentationPage />} />
```

3. Create the requested slide components and populate `src/slides/slides.tsx`. An empty registry intentionally shows “No slides yet.” It is not a finished presentation.
4. Adapt `src/slides/theme.css` to the presentation design, then run the app checks.

The speaker view opens an audience window using `/present/:id?audience=1`. Keep those routes on the same origin so local slide synchronization works. Builder navigation also relies on `/slides/:id` as its fallback route.
