---
name: slides
description: Build and edit presentations using the installed Base44 slides engine.
---

# Slides

Read `installation/install.md` for the initial route connection. The kit provides presentation behavior, not a deck design. Create original slide layouts and artwork for the user's subject; there are no example slides to imitate.

## Ownership

- Keep `src/slides/engine/` unchanged. It supplies navigation, thumbnails, Builder messages, speaker notes, timer, audience synchronization and printing.
- Freely design slide components in `src/slides/content/` and supporting components elsewhere. Use image assets as appropriate. The engine renders slides on a 1280 × 720 canvas and scales it to fit.
- Edit `src/slides/slides.tsx` to describe the deck and its order.
- Customize `src/slides/theme.css` to make the presentation controls match the deck. Change the supplied color variables and add typography, spacing, borders, radii and control selectors as needed. This is not a prescribed dark theme or a limit on slide artwork.
- Translate every label and label function in `src/slides/strings.js` into the deck's language, including empty states, speaker controls and accessibility labels. Set `presentationLocale.lang` and `dir` (`rtl` when appropriate). Keep the engine unchanged.
- App routes, `src/App.jsx`, `src/main.jsx` and normal app configuration remain editable. Preserve the presentation route connection described in the setup guide.
- Thumbnail rail navigation belongs only to Builder. Do not add a filmstrip to the app or replace the engine's presentation controller.
- The slide view has no Overview, Speaker, Audience or Print buttons, inside Builder or when opened directly. Do not add them; Builder links the published speaker and presentation views.

## Choose the edit location

- Redesign, add or reorder slides: slide components and `src/slides/slides.tsx`.
- Change controls' appearance: `src/slides/theme.css`; retain the existing player.
- Translate controls: `src/slides/strings.js`.
- Write presenter notes in `src/slides/speaker-notes.json`: an object mapping each stable slide ID to an array of note paragraphs. The Builder notes panel edits the same file. Keep other slides’ entries intact; use `[]` to clear notes. A JSON entry takes precedence over registry `speakerNotes`.
- Fix missing views: app routes, following `installation/install.md`.
- A request appears to need engine changes: first look for a content, theme or route solution; explain any remaining limitation rather than replacing the engine.

## Keep slide text editable

Write static headings, body copy and labels as literal text inside native JSX elements (`h1`, `h2`, `p`, `li`, etc.) in each slide component. Edit mode needs to locate that text in source; a shared component rendering `<h2>{title}</h2>` cannot reliably edit the caller's `title` prop.

Share layout, styling and artwork through components, but pass the actual text-bearing JSX as children:

```jsx
export default function Polar() {
  return (
    <HabitatLayout>
      <h2>Polar &amp; tundra</h2>
      <p>Life adapts to months of darkness and freezing temperatures.</p>
    </HabitatLayout>
  );
}
```

Keep these native text elements in the slide; wrapping the copy in `<Heading>` that renders `<h2>{children}</h2>` has the same limitation. Do not move static slide copy into text props or data objects just to reuse markup. Genuinely data-driven content can remain dynamic, but may require chat edits. This changes source structure, not the freedom to design each slide.

## Slide registry

```tsx
import Opening from './content/Opening';

export const slides = [
  {
    id: 'opening',
    title: 'The opening idea',
    subtitle: 'Optional rail summary',
    Component: Opening,
    speakerNotes: ['A useful cue for the presenter.'],
  },
];
```

Use unique stable lowercase kebab-case IDs (maximum 64 characters) and at most 100 slides. Keep IDs when editing existing slides so navigation links remain valid. Titles and notes should use the deck's language.

Slides must render without side effects: thumbnails and print render the same component. Do not fetch data, start timers, write storage, open windows or register global listeners while rendering a slide.

## Slide numbers

Never type a slide's number or the slide count into slide content: reordering, adding or removing a slide leaves typed numbers wrong. Read them from `useSlidePosition()` in `@/slides/engine/SlidePositionContext`. It returns `{ number, total }` for the slide's place in `src/slides/slides.tsx`, in every view, and a shared footer component can call it directly.

```jsx
import { useSlidePosition } from '@/slides/engine/SlidePositionContext';

export default function DeckFooter() {
  const { number, total } = useSlidePosition();
  return <p>{String(number).padStart(2, '0')} / {String(total).padStart(2, '0')}</p>;
}
```

## Motion

Motion is seasoning, not structure. A deck reads well with no animation at all, and most slides should have none. Animate only where the order of appearance helps the audience follow the point:

- A build-up the presenter talks through, such as a list of reasons revealed one at a time.
- The one number, chart or image the slide exists for, brought in after its context.
- A before/after or problem/solution reveal.

Keep it restrained:

- Leave title, section, quote and closing slides still unless the user asks.
- At most three steps on a slide, and only on content that carries the message. Never animate backgrounds, logos, footers, slide numbers or decorative shapes.
- Pick one or two effects for the whole deck and reuse them. `fade` and `rise` suit almost everything; save `zoom` and the side entrances for a single focal element.
- Stay at the default speed or `fast`; use `slow` only for one deliberate reveal.
- When the user asks for "animations" or "more motion", add them to the slides where a reveal serves the story, not to every element.

Use the engine's motion attributes on the native element in the slide file:

```jsx
<h2>Why teams switch</h2>
<li data-motion="rise">Drafts in minutes</li>
<li data-motion="rise" data-motion-order="2">Edits by chat</li>
```

- `data-motion` is one of `fade`, `rise`, `from-left`, `from-right` or `zoom`.
- `data-motion-order` is the step, `1` to `10` (default `1`). Elements with the same step play together; each step starts 0.4 s after the previous one.
- `data-motion-pace` is `slow` or `fast`; leave it off for the default speed.
- `data-motion-start="click"` on a step's first element makes that step wait for the presenter's click or arrow key; later steps follow it 0.4 s apart until the next click step. Use it only when the presenter needs control, such as revealing an answer or building points they talk through. Leave it off by default.
- Write these as literal string attributes on a native element (`h2`, `p`, `li`, `img`, `div`) in the slide's own component, not through props, spreads or conditions. Don't put them on an `svg` or an icon component: wrap it in a `div` and animate the `div`. The Builder's Animations panel reads and edits them there, and PowerPoint and Google Slides exports carry them as native animations.
- Elements rendered from one `.map()` share one source element, so they animate together. Write the items out when they should appear one at a time.

The engine freezes CSS animations and transitions in thumbnails, overview and print, so make each element's resting style its finished look and animate into it. Don't add custom CSS or JavaScript entrance animations: they don't export, the Animations panel can't edit them, and they compete with `data-motion`. Ambient motion inside a visual (a chart that draws in) is acceptable when it is the slide's focal point. JavaScript motion such as `framer-motion` is not frozen: check `useSlideMode()` from `@/slides/engine/SlideModeContext` and animate only in `present` and `canvas` modes (for example, `initial={false}` otherwise).

## Before finishing any build or edit

Run this JavaScript through `exec_tool` from the app root:

```js
return require('./.agents/skills/slides/verification/check-engine.cjs')();
```

Read the returned `ok`, `errors` and `next` fields. This checks the app's installed engine files; it does not build or retest the kit. It leaves all files unchanged and reports changed, missing or extra engine files.

If it reports a change, restore changed or missing engine files from a working Git commit. Remove extra engine files; move any useful slide content outside the engine first. Replace a linked engine directory with the real engine directory. Preserve slide content, theme and labels, then run the check again. Do not edit the checker or its baseline to hide a failure. Re-running the installer does not restore an already-installed kit. If no working engine commit is available, report the failure instead of replacing the player or claiming success.

A passing engine check is not a finished presentation. Populate the slide registry, connect the routes in `installation/install.md`, and check the live app: selecting slides in the Builder rail, standalone navigation, speaker notes, audience synchronization and print. Fix content, styling and route problems in their editable files. A normal successful compile alone does not prove these connections work.
