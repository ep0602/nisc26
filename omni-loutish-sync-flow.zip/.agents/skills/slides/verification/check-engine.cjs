const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');

const baseline = require('./engine-sha256.json');

module.exports = function checkEngine() {
  const engineDirectory = path.resolve('src/slides/engine');
  const errors = [];
  const found = new Set();
  const root = fs.lstatSync(engineDirectory, { throwIfNoEntry: false });
  if (root && !root.isDirectory()) {
    return {
      ok: false,
      errors: ['src/slides/engine: expected a real directory'],
      next: 'Restore the engine as a real directory from a working Git commit, preserving slide content, theme and labels. Then rerun this check.',
    };
  }

  function inspect(directory, prefix = '') {
    if (!fs.existsSync(directory)) return;
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const name = prefix + entry.name;
      const file = path.join(directory, entry.name);
      if (entry.isDirectory()) {
        inspect(file, `${name}/`);
        continue;
      }
      found.add(name);
      if (entry.isSymbolicLink() || !entry.isFile()) {
        errors.push(`${name}: expected a regular file`);
      } else if (!Object.hasOwn(baseline, name)) {
        errors.push(`${name}: extra engine file`);
      } else if (createHash('sha256').update(fs.readFileSync(file)).digest('hex') !== baseline[name]) {
        errors.push(`${name}: changed engine file`);
      }
    }
  }

  inspect(engineDirectory);
  for (const name of Object.keys(baseline)) {
    if (!found.has(name)) errors.push(`${name}: missing engine file`);
  }
  return {
    ok: errors.length === 0,
    errors,
    next: errors.length
      ? 'Restore changed or missing engine files from a working Git commit. Remove extra engine files, moving useful slide content outside the engine first. Preserve slide content, theme and labels, then rerun this check.'
      : 'Engine unchanged. Check slide content and the live navigation, speaker, audience and print views.',
  };
};
